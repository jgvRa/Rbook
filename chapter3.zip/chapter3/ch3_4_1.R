library(quantmod)

TSLA = getSymbols("TSLA", from="2020-01-01", to = "2024-12-31", auto.assign = FALSE)

pdf("chrt_tsla1w.pdf", width = 6, height = 4)
chartSeries(TSLA, theme = "white", subset = "last 1 weeks")
dev.off()

pdf("chrt_tsla2w.pdf", width = 6, height = 4)
chartSeries(TSLA, theme = "white", subset = "last 2 weeks")
dev.off()

pdf("chrt_tsla3w.pdf", width = 6, height = 4)
chartSeries(TSLA, theme = "white", subset = "last 3 weeks")
dev.off()

pdf("chrt_tsla1m.pdf", width = 6, height = 4)
chartSeries(TSLA, theme = "white", subset = "last 1 month")
dev.off()