library(quantmod)

TSLA = getSymbols("TSLA",from = "2020-01-01", to = "2024-12-31", auto.assign = FALSE)

chartSeries(TSLA, type = "bar", 
            subset = '2024-09::2024-12',
            theme = chartTheme("white", up.col="black"))

pdf('chrt_tsla-line.pdf', width=6, height = 4)
chartSeries(TSLA, type = "bar", 
            subset = '2024-09::2024-12',
            theme = chartTheme("white", up.col="black"))
dev.off()
