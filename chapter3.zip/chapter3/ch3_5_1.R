require("quantmod");require("highcharter")

ticker = "SPY"

STK = getSymbols(ticker, from="1990-01-01", auto.assign = FALSE)

highchart(type="stock") %>%
  hc_chart(inverted=FALSE) %>%
  hc_title(text = ticker) %>% 
  hc_add_series(STK, yAxis = 0, showInLegend = FALSE, color="black") %>%
  hc_add_yAxis(nid = 1L, title = list(text="Prices"), relative=2) %>% 
  hc_add_series(Vo(STK), yAxis=1, type="column", showInLegend = FALSE) %>%
  hc_add_yAxis(nid=2L, title = list(text="Volume"), relative = 1)

e <- new.env()
tickers = c("TLT", "SPY", "EEM", "DIA", "QQQ")
getSymbols(tickers, env = e, from="2010-01-01")
RETS = do.call(merge, eapply(e, Ad))
colnames(RETS) = gsub(".Adjusted", "", names(RETS))

yRet <- lapply(as.list(tickers), function(x) annualReturn(RETS[,x]))
yRet <- round(do.call(merge, yRet), 4)
colnames(yRet) = tickers

df = do.call(rbind, lapply(as.list(tickers), function(x){
  tmp <- data.frame(coredata(yRet[,x]), Date = index(yRet[,x]))
  tmp$symbol = x
  colnames(tmp)[1] = "return"
  tmp
}))

