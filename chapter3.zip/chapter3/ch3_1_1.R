library(quantmod)

TSLA = getSymbols("TSLA",from = "2020-01-01", to = "2024-12-31", auto.assign = FALSE)

chartSeries(TSLA, type = "line", 
            theme = chartTheme("white", up.col="black"))

pdf('chrt_tsla-line.pdf', width=6, height = 4)
chartSeries(TSLA, type="line", 
            theme = chartTheme("white", up.col="black"))
dev.off()
