require("highcharter");require("scales");require("derivmkts");require("RQuantLib")

rf_rate = 0.0550
# calculate payoff for calls at expiration
get_call_exp = function(payoff, op_strike, call_prc,short=FALSE){
  if(short){
    call_price = -ifelse(payoff$uPrc< op_strike, 0-call_prc, (payoff$uPrc-op_strike)-call_prc)*100
  }else{
    call_price = ifelse(payoff$uPrc < op_strike, 0-call_prc, (payoff$uPrc-op_strike)-call_prc)*100
  }
  call_price
}
# calculate payoff for calls before expiration
get_call_pnl = function(payoff, op_strike,ivol,trade_date, op_exp, call_prc, short=FALSE, rf_rate){
  if(short){
    # add current theoretical pricing for option
    PnL = (-round(derivmkts::bscall(s = payoff$uPrc, k = op_strike, v = ivol, r = rf_rate, 
                                    tt = RQuantLib::yearFraction(startDates = as.Date(trade_date), endDates = as.Date(op_exp), dayCounters = 1),
                                    d = 0
    ),2)*100) - (-call_prc*100)
  }else{
    # add current theoretical pricing for option
    PnL = (round(derivmkts::bscall(s = payoff$uPrc, k = op_strike, v = ivol, r = rf_rate, 
                                   tt = RQuantLib::yearFraction(startDates = as.Date(trade_date), endDates = as.Date(op_exp), dayCounters = 1),
                                   d = 0
    ),2)*100) - (call_prc*100)
  }
  # return PnL
  PnL
}
# calculate payoff for puts at expiration
get_put_exp  = function(payoff, op_strike, put_prc, short=FALSE){
  if(short){
    # create put payoff
    put_price = -ifelse(payoff$uPrc > op_strike, 0-put_prc, (op_strike-payoff$uPrc)-put_prc)*100  
  }else{
    # create put payoff
    put_price = ifelse(payoff$uPrc > op_strike, 0-put_prc, (op_strike-payoff$uPrc)-put_prc)*100
  }
  put_price
}
# calculate payoff for puts before expiration
get_put_pnl = function(payoff, op_strike,ivol,trade_date, op_exp, put_prc, short=FALSE,rf_rate){
  if(short){
    # add current theoretical pricing for option
    PnL = (-round(derivmkts::bsput(s = payoff$uPrc, k = op_strike, v = ivol, r = rf_rate, 
                                   tt = RQuantLib::yearFraction(startDates = as.Date(trade_date), endDates = as.Date(op_exp), dayCounters = 1),
                                   d = 0),2)*100) - (-put_prc*100)
  }else{
    # add current theoretical pricing for option
    PnL = (round(derivmkts::bsput(s = payoff$uPrc, k = op_strike, v = ivol, r = rf_rate, 
                                  tt = RQuantLib::yearFraction(startDates = as.Date(trade_date), endDates = as.Date(op_exp), dayCounters = 1),
                                  d = 0),2)*100) - (put_prc*100)
  }
  # return PnL
  PnL
}
# ******************************************************************************************************************************************************
# ******************************************************************************************************************************************************
# hichcharter - calls
hc_call= function(und_sym, op_strike, und_prc, call_prc, ivol, op_exp, pct_range, trade_date, short=FALSE,rf_rate){
  # calculate break-even point
  hi_be = op_strike+call_prc
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = op_strike, 
                                     call_prc = call_prc, short = TRUE)
    # add current theoretical pricing for option
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol, 
                              trade_date = trade_date,op_exp = op_exp,
                              call_prc = call_prc,short = TRUE, rf_rate = rf_rate)
    # assign name
    op_name = paste0(op_strike, " Short Call")
  }else{
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = op_strike,
                                     call_prc = call_prc,short = FALSE)
    # add current theoretical pricing for option
    payoff$PnL = get_call_pnl(payoff = payoff,op_strike = op_strike,ivol = ivol,
                              trade_date = trade_date,op_exp = op_exp,call_prc = call_prc,
                              short = FALSE, rf_rate = rf_rate)
    # assign name
    op_name = paste0(op_strike, " Long Call")
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$call_price <= 0,],hcaes(x = 'uPrc', y = 'call_price'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$call_price >= 0,],hcaes(x = 'uPrc', y = 'call_price'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ", op_strike, " Call Option | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Price: ", scales::dollar(hi_be), " | Current Price: ", 
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(call_prc))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - puts
hc_put= function(und_sym, op_strike, und_prc, put_prc, ivol, op_exp, pct_range, trade_date, short=FALSE, rf_rate){
  # calculate break-even point
  lo_be = op_strike-put_prc
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = op_strike, put_prc = put_prc, 
                                   short = TRUE)
    # add current theoretical pricing for option
    payoff$PnL = get_put_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol,
                             trade_date = trade_date, op_exp = op_exp,
                             put_prc = put_prc, short = TRUE, rf_rate = rf_rate)
    # assign name
    op_name = paste0(op_strike, " Short Put")
  }else{
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = op_strike, put_prc = put_prc)
    # add current theoretical pricing for option
    payoff$PnL = get_put_pnl(payoff=payoff, op_strike = op_strike, ivol = ivol, 
                             trade_date = trade_date, op_exp = op_exp, 
                             put_prc = put_prc,rf_rate = rf_rate)
    # assign name
    op_name = paste0(op_strike, " Long Put")
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$put_price <= 0,],hcaes(x = 'uPrc', y = 'put_price'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$put_price >= 0,],hcaes(x = 'uPrc', y = 'put_price'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",op_name," | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Price: ", scales::dollar(lo_be), " | Current Price: ", scales::dollar(und_prc), 
                            " | Option Price: ",scales::dollar(put_prc))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - call spreads
hc_call_vrt = function(und_sym, long_strike, short_strike,ivol_long, ivol_short, und_prc, long_call_prc, short_call_prc, op_exp, 
                       pct_range, trade_date, short=FALSE,rf_rate){
  # calculate spread cost
  sprd_cost = long_call_prc-short_call_prc
  # spread width
  srtk_width = abs(long_strike-short_strike)
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create short call payoff
    payoff$short_call_price = get_call_exp(payoff = payoff,op_strike = short_strike, call_prc = short_call_prc, short = TRUE)
    # create long call payoff
    payoff$long_call_price = get_call_exp(payoff = payoff, op_strike = long_strike, call_prc = long_call_prc, short = FALSE)
    # add net price
    payoff$netPrc = payoff$long_call_price + payoff$short_call_price
    
    # add current theoretical pricing for option
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = long_strike, ivol = ivol_long, trade_date = trade_date, 
                              op_exp = op_exp, call_prc = long_call_prc,short = FALSE, rf_rate = rf_rate) + 
      get_call_pnl(payoff = payoff, op_strike = short_strike, ivol = ivol_short, trade_date = trade_date, 
                   op_exp = op_exp, call_prc = short_call_prc, short = TRUE, rf_rate = rf_rate)
    # calculate break-even
    be = long_strike-(srtk_width+sprd_cost)
    # assign spread name
    sprd_nom = paste0(short_strike,"/",long_strike, " Bear Call Spread")
  }else{
    # create long call payoff
    payoff$long_call_price = get_call_exp(payoff = payoff, op_strike = long_strike, call_prc = long_call_prc, short = FALSE)
    # create short call payoff
    payoff$short_call_price = get_call_exp(payoff=payoff, op_strike = short_strike, call_prc = short_call_prc, short = TRUE)
    # add net price
    payoff$netPrc = payoff$long_call_price + payoff$short_call_price
    
    # add current theoretical pricing for option
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = long_strike, ivol = ivol_long, trade_date = trade_date, 
                              op_exp = op_exp, call_prc = long_call_prc,short = FALSE, rf_rate = rf_rate) + 
      get_call_pnl(payoff = payoff, op_strike = short_strike, ivol = ivol_short, trade_date = trade_date, 
                   op_exp = op_exp, call_prc = short_call_prc, short = TRUE, rf_rate = rf_rate)
    # calculate break-even
    be = long_strike + sprd_cost
    # assign spread name
    sprd_nom = paste0(long_strike,"/",short_strike, " Bull Call Spread")
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$netPrc <= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$netPrc >= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom," | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Price: ", scales::dollar(be), " | Current Price: ", scales::dollar(und_prc),
                            " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - put spreads
hc_put_vrt = function(und_sym, long_strike, short_strike, und_prc, ivol_long, ivol_short,long_put_prc, short_put_prc, op_exp, 
                      pct_range, trade_date, short=FALSE,rf_rate){
  # calculate spread cost
  sprd_cost = long_put_prc-short_put_prc
  # spread width
  srtk_width = abs(long_strike-short_strike)
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create short call payoff
    payoff$short_put_price = get_put_exp(payoff = payoff,op_strike = short_strike, put_prc = short_put_prc, short = TRUE)
    # create long call payoff
    payoff$long_put_price = get_put_exp(payoff = payoff, op_strike = long_strike, put_prc = long_put_prc, short = FALSE)
    # add net price
    payoff$netPrc = payoff$long_put_price + payoff$short_put_price
    # add current theoretical pricing for option
    payoff$PnL = get_put_pnl(payoff = payoff, op_strike = long_strike, ivol = ivol_long, trade_date = trade_date, 
                             op_exp = op_exp, put_prc = long_put_prc,short = FALSE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = short_strike, ivol = ivol_short, trade_date = trade_date, 
                  op_exp = op_exp, put_prc = short_put_prc, short = TRUE, rf_rate = rf_rate)
    # calculate break-even
    be = long_strike+(srtk_width+sprd_cost)
    # assign spread name
    sprd_nom = paste0(short_strike,"/",long_strike, " Bull Put Spread")
  }else{  
    # create long call payoff
    payoff$long_put_price = get_put_exp(payoff = payoff, op_strike = long_strike, put_prc = long_put_prc, short = FALSE)
    # create short call payoff
    payoff$short_put_price = get_put_exp(payoff=payoff, op_strike = short_strike, put_prc = short_put_prc, short = TRUE)
    # add net price
    payoff$netPrc = payoff$long_put_price + payoff$short_put_price
    
    # add current theoretical pricing for option
    payoff$PnL = get_put_pnl(payoff = payoff, op_strike = long_strike, ivol = ivol_long, trade_date = trade_date, 
                             op_exp = op_exp, put_prc = long_put_prc,short = FALSE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = short_strike, ivol = ivol_short, trade_date = trade_date, 
                  op_exp = op_exp, put_prc = short_put_prc, short = TRUE, rf_rate = rf_rate)
    # calculate break-even
    be = long_strike - sprd_cost
    # assign spread name
    sprd_nom = paste0(long_strike,"/",short_strike, " Bear Put Spread")
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$netPrc <= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$netPrc >= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom," | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Price: ", scales::dollar(be), " | Current Price: ", scales::dollar(und_prc),
                            " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - condor spreads
hc_condor = function(und_sym, long_strike1, short_strike1, short_strike2, long_strike2, opType, und_prc, 
                     ivol_long1,ivol_short1,ivol_short2,ivol_long2,
                     longOp_prc1, shortOp_prc1, shortOp_prc2, longOp_prc2, op_exp, pct_range, trade_date,
                     short=FALSE,rf_rate){
  # calculate spread cost
  sprd_cost = (longOp_prc1-shortOp_prc1) + (-shortOp_prc2+longOp_prc2)
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  # get implied vols and opt pricing
  if(opType=="call"){
    
    # create short call payoff
    payoff$short_call_price1 = get_call_exp(payoff=payoff, op_strike = short_strike1, call_prc = shortOp_prc1, short = TRUE)
    # create long call payoff
    payoff$long_call_price1 = get_call_exp(payoff = payoff, op_strike = long_strike1, call_prc = longOp_prc1, short = FALSE)
    # create long call payoff
    payoff$long_call_price2 = get_call_exp(payoff = payoff, op_strike = long_strike2, call_prc = longOp_prc2, short = FALSE)
    # create short call payoff
    payoff$short_call_price2 = get_call_exp(payoff=payoff, op_strike = short_strike2, call_prc = shortOp_prc2, short = TRUE)
    # add net price
    payoff$netPrc = payoff$long_call_price1 + payoff$short_call_price1 + payoff$long_call_price2 + payoff$short_call_price2
    # add current theoretical pricing for option
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = long_strike1, ivol = ivol_long1, trade_date = trade_date, 
                              op_exp = op_exp, call_prc = longOp_prc1,short = FALSE, rf_rate = rf_rate) + 
      get_call_pnl(payoff = payoff, op_strike = short_strike1, ivol = ivol_short1, trade_date = trade_date, 
                   op_exp = op_exp, call_prc = shortOp_prc1, short = TRUE, rf_rate = rf_rate) +
      get_call_pnl(payoff = payoff, op_strike = short_strike2, ivol = ivol_long1, trade_date = trade_date, 
                   op_exp = op_exp, call_prc = shortOp_prc2,short = TRUE, rf_rate = rf_rate) + 
      get_call_pnl(payoff = payoff, op_strike = long_strike2, ivol = ivol_short1, trade_date = trade_date, 
                   op_exp = op_exp, call_prc = longOp_prc2, short = FALSE, rf_rate = rf_rate)
    
    
    
  }else{
    
    # create long put payoff
    payoff$long_put_price1 = get_put_exp(payoff = payoff, op_strike = long_strike1, put_prc = longOp_prc1, short = FALSE)
    # create short put payoff
    payoff$short_put_price1 = get_put_exp(payoff=payoff, op_strike = short_strike1, put_prc = shortOp_prc1, short = TRUE)
    # create short put payoff
    payoff$short_put_price2 = get_put_exp(payoff=payoff, op_strike = short_strike2, put_prc = shortOp_prc2, short = TRUE)
    # create long put payoff
    payoff$long_put_price2 = get_put_exp(payoff = payoff, op_strike = long_strike2, put_prc = longOp_prc2, short = FALSE)
    # add net price
    payoff$netPrc = payoff$long_put_price1 + payoff$short_put_price1 + payoff$long_put_price2 + payoff$short_put_price2
    # add current theoretical pricing for option
    payoff$PnL = get_put_pnl(payoff = payoff, op_strike = long_strike1, ivol = ivol_long1, trade_date = trade_date, 
                             op_exp = op_exp, put_prc = longOp_prc1,short = FALSE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = short_strike1, ivol = ivol_short1, trade_date = trade_date, 
                  op_exp = op_exp, put_prc = shortOp_prc1, short = TRUE, rf_rate = rf_rate) +
      get_put_pnl(payoff = payoff, op_strike = short_strike2, ivol = ivol_long1, trade_date = trade_date, 
                  op_exp = op_exp, put_prc = shortOp_prc2,short = TRUE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = long_strike2, ivol = ivol_short1, trade_date = trade_date, 
                  op_exp = op_exp, put_prc = longOp_prc2, short = FALSE, rf_rate = rf_rate)
  }
  
  if(short){
    if(opType == "call"){
      # calculate break-even
      lo_be = short_strike1 - sprd_cost
      hi_be = short_strike2 + sprd_cost
      # assign spread name
      sprd_nom = paste0("+",long_strike1,"c/-",short_strike1,"c/-",short_strike2,"c/+",long_strike2, "c Short-Call Condor")
    }else{
      
      # calculate break-even
      lo_be = long_strike1 - sprd_cost
      hi_be = long_strike2 + sprd_cost
      # assign spread name
      sprd_nom = paste0("+",long_strike1,"p/-",short_strike1,"p/-",short_strike2,"p/+",long_strike2, "p Short-Put Condor")
    }
    
  }else{
    if(opType == "call"){
      # calculate break-even
      lo_be = long_strike1 + sprd_cost
      hi_be = long_strike2 - sprd_cost
      # assign spread name
      sprd_nom = paste0("+",long_strike1,"c/-",short_strike1,"c/-",short_strike2,"c/+",long_strike2, "c Long-Call Condor")
    }else{
      # calculate break-even
      lo_be = long_strike1 + sprd_cost
      hi_be = long_strike2 - sprd_cost
      # assign spread name
      sprd_nom = paste0("+",long_strike1,"p/-",short_strike1,"p/-",short_strike2,"p/+",long_strike2, "p Long-Put Condor")
    }
    
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$netPrc <= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$netPrc >= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom," | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Prices: ",scales::dollar(lo_be), " / ",scales::dollar(hi_be), " | Current Price: ",
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - iron condor spreads
hc_ironCondor = function(und_sym, long_call_strike, short_call_strike, long_put_strike,short_put_strike, und_prc, 
                         ivol_long_call,ivol_short_call,ivol_long_put,ivol_short_put,
                         long_call_prc, short_call_prc, long_put_prc, short_put_prc, op_exp, pct_range, trade_date,
                         short=FALSE,rf_rate){
  # calculate spread cost
  sprd_cost = (long_call_prc-short_call_prc) + (long_put_prc-short_put_prc)
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  # create long call payoff
  payoff$long_call_price = get_call_exp(payoff = payoff, op_strike = long_call_strike, call_prc = long_call_prc, short = FALSE)
  # create short call payoff
  payoff$short_call_price = get_call_exp(payoff=payoff, op_strike = short_call_strike, call_prc = short_call_prc, short = TRUE)
  # create short call payoff
  payoff$short_put_price = get_put_exp(payoff=payoff, op_strike = short_put_strike, put_prc = short_put_prc, short = TRUE)
  # create long call payoff
  payoff$long_put_price = get_put_exp(payoff = payoff, op_strike = long_put_strike, put_prc = long_put_prc, short = FALSE)
  # add net price
  payoff$netPrc = payoff$long_call_price + payoff$short_call_price + payoff$long_put_price + payoff$short_put_price
  # add current theoretical pricing for option
  payoff$PnL = get_call_pnl(payoff = payoff, op_strike = long_call_strike, ivol = ivol_long_call, trade_date = trade_date, 
                            op_exp = op_exp, call_prc = long_call_prc,short = FALSE, rf_rate = rf_rate) + 
    get_call_pnl(payoff = payoff, op_strike = short_call_strike, ivol = ivol_short_call, trade_date = trade_date, 
                 op_exp = op_exp, call_prc = short_call_prc, short = TRUE, rf_rate = rf_rate) +
    get_put_pnl(payoff = payoff, op_strike = long_put_strike, ivol = ivol_long_put, trade_date = trade_date, 
                op_exp = op_exp, put_prc = long_put_prc,short = FALSE, rf_rate = rf_rate) + 
    get_put_pnl(payoff = payoff, op_strike = short_put_strike, ivol = ivol_short_put, trade_date = trade_date, 
                op_exp = op_exp, put_prc = short_put_prc, short = TRUE, rf_rate = rf_rate)
  if(short){
    # calculate break-even
    lo_be = short_put_strike + sprd_cost
    hi_be = short_call_strike - sprd_cost
    # assign spread name
    sprd_nom = paste0("-",short_call_strike,"c/+",long_call_strike,"c/-",short_put_strike,"p/+",long_put_strike, "p Short-Call Iron Condor")
    
  }else{
    # calculate break-even
    lo_be = long_put_strike - sprd_cost
    hi_be = long_call_strike + sprd_cost
    # assign spread name
    sprd_nom = paste0("+",long_call_strike,"c/-",short_call_strike,"c/+",long_put_strike,"p/-",short_put_strike, "p Long-Call Iron Condor")
  }
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$netPrc <= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$netPrc >= 0,],hcaes(x = 'uPrc', y = 'netPrc'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom," | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Prices: ",scales::dollar(lo_be), " / ",scales::dollar(hi_be), " | Current Price: ",
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - straddles
hc_straddle = function(und_sym,op_strike, und_prc,ivol_call, ivol_put, call_prc, put_prc, op_exp, pct_range, short=FALSE,trade_date, rf_rate){
  # calculate break-even point
  sprd_cost = call_prc+put_prc
  lo_be = op_strike-sprd_cost
  hi_be = op_strike+sprd_cost
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = op_strike, call_prc = call_prc,short = TRUE)
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = op_strike, put_prc = put_prc, short = TRUE)
    # get pricing before expiration
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol_call, trade_date = trade_date,
                              op_exp = op_exp, call_prc = call_prc, short = TRUE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol_put, trade_date = trade_date, 
                  op_exp = op_exp,put_prc = put_prc, short = TRUE, rf_rate = rf_rate)
    # assign spread name
    sprd_nom = paste0("-",op_strike,"c/",op_strike,"p Straddle")
    # reassign sprd cost since credit
    sprd_cost = -sprd_cost
  }else{
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = op_strike, call_prc = call_prc,short = FALSE)
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = op_strike, put_prc = put_prc, short = FALSE)
    # get pricing before expiration
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol_call, trade_date = trade_date,
                              op_exp = op_exp, call_prc = call_prc, short = FALSE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = op_strike, ivol = ivol_put, trade_date = trade_date, 
                  op_exp = op_exp,put_prc = put_prc, short = FALSE, rf_rate = rf_rate)
    # assign spread name
    sprd_nom = paste0("+",op_strike,"c/",op_strike,"p Straddle")
  }
  # add net pricing
  payoff$net_price = payoff$call_price+payoff$put_price
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$net_price <= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$net_price >= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom, " | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Prices: ",scales::dollar(lo_be), " / ",scales::dollar(hi_be), " | Current Price: ",
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - strangles
hc_strangle = function(und_sym,call_strike, put_strike, und_prc, call_prc, put_prc, ivol_call, ivol_put, op_exp, pct_range,trade_date, short=FALSE, rf_rate){
  # calculate break-even point
  sprd_cost = call_prc+put_prc
  lo_be = put_strike-sprd_cost
  hi_be = call_strike + sprd_cost
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  
  if(short){
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = call_strike, call_prc = call_prc,short = TRUE)
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = put_strike, put_prc = put_prc, short = TRUE)
    # get pricing before expiration
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = call_strike, ivol = ivol_call, trade_date = trade_date,
                              op_exp = op_exp, call_prc = call_prc, short = TRUE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = put_strike, ivol = ivol_put, trade_date = trade_date, 
                  op_exp = op_exp,put_prc = put_prc, short = TRUE, rf_rate = rf_rate)
    # assign spread name
    sprd_nom = paste0(call_strike,"c/",put_strike,"p Short Strangle")
    # reassign sprd cost since credit
    sprd_cost = -sprd_cost
  }else{
    # create call payoff
    payoff$call_price = get_call_exp(payoff = payoff, op_strike = call_strike, call_prc = call_prc,short = FALSE)
    # create put payoff
    payoff$put_price = get_put_exp(payoff = payoff, op_strike = put_strike, put_prc = put_prc, short = FALSE)
    # get pricing before expiration
    payoff$PnL = get_call_pnl(payoff = payoff, op_strike = call_strike, ivol = ivol_call, trade_date = trade_date,
                              op_exp = op_exp, call_prc = call_prc, short = FALSE, rf_rate = rf_rate) + 
      get_put_pnl(payoff = payoff, op_strike = put_strike, ivol = ivol_put, trade_date = trade_date, 
                  op_exp = op_exp,put_prc = put_prc, short = FALSE, rf_rate = rf_rate)
    # assign spread name
    sprd_nom = paste0(call_strike,"c/",put_strike,"p Long Strangle")
  }
  # add net pricing
  payoff$net_price = payoff$call_price+payoff$put_price
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$net_price <= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$net_price >= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom, " | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Prices: ",scales::dollar(lo_be), " / ",scales::dollar(hi_be), " | Current Price: ",
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
# hichcharter - butterfly
hc_bfly = function(und_sym,lo_wing_strike, body_strike, hi_wing_strike, und_prc, lo_wing_prc, body_prc, hi_wing_prc, 
                   op_exp, ivol_lo_wng,ivol_body,ivol_hi_wng,opType,trade_date, pct_range, short=FALSE, rf_rate){
  # calculate break-even point
  sprd_cost = lo_wing_prc+(-2*body_prc)+hi_wing_prc
  lo_be = lo_wing_strike + sprd_cost
  hi_be = hi_wing_strike - sprd_cost
  # calculate stock range at expiration
  start_prc = round(und_prc*(1-pct_range),0)
  end_prc = round(und_prc*(1+pct_range),0)
  # create a data frame to keep pricing at expiration
  payoff <- data.frame(uPrc = seq(start_prc, end_prc,0.10))
  if(opType=="call"){
    
    if(short){
      # create lower wing payoff
      payoff$low_wing_price = get_call_exp(payoff = payoff, op_strike =lo_wing_strike, call_prc = lo_wing_prc,short = TRUE)
      # create body payoff
      payoff$body_price = get_call_exp(payoff = payoff, op_strike =body_strike, call_prc = body_prc,short = FALSE)*2
      # create lower wing payoff
      payoff$high_wing_price = get_call_exp(payoff = payoff, op_strike =hi_wing_strike, call_prc = hi_wing_prc,short = TRUE)
      
      # get pricing before expiration
      payoff$PnL = get_call_pnl(payoff = payoff, op_strike = lo_wing_strike, ivol = ivol_lo_wng, trade_date = trade_date,
                                op_exp = op_exp, call_prc = lo_wing_prc, short = TRUE, rf_rate = rf_rate) + 
        get_call_pnl(payoff = payoff, op_strike = body_strike, ivol = ivol_body, trade_date = trade_date, 
                     op_exp = op_exp,call_prc = body_prc, short = FALSE, rf_rate = rf_rate)*2 + 
        get_call_pnl(payoff = payoff, op_strike = hi_wing_strike, ivol = ivol_hi_wng, trade_date = trade_date, 
                     op_exp = op_exp,call_prc = hi_wing_prc, short = TRUE, rf_rate = rf_rate)
      # add net pricing
      payoff$net_price = payoff$low_wing_price+payoff$body_price+payoff$high_wing_price    
      # assign spread name
      sprd_nom = paste0("-",lo_wing_strike,"c/+",body_strike,"c/-",hi_wing_strike,"c Short Butterfly")
    }else{
      # create lower wing payoff
      payoff$low_wing_price = get_call_exp(payoff = payoff, op_strike =lo_wing_strike, call_prc = lo_wing_prc,short = FALSE)
      # create body payoff
      payoff$body_price = get_call_exp(payoff = payoff, op_strike =body_strike, call_prc = body_prc,short = TRUE)*2
      # create lower wing payoff
      payoff$high_wing_price = get_call_exp(payoff = payoff, op_strike =hi_wing_strike, call_prc = hi_wing_prc,short = FALSE)
      
      # get pricing before expiration
      payoff$PnL = get_call_pnl(payoff = payoff, op_strike = lo_wing_strike, ivol = ivol_lo_wng, trade_date = trade_date,
                                op_exp = op_exp, call_prc = lo_wing_prc, short = FALSE, rf_rate = rf_rate) + 
        get_call_pnl(payoff = payoff, op_strike = body_strike, ivol = ivol_body, trade_date = trade_date, 
                     op_exp = op_exp,call_prc = body_prc, short = TRUE, rf_rate = rf_rate)*2 + 
        get_call_pnl(payoff = payoff, op_strike = hi_wing_strike, ivol = ivol_hi_wng, trade_date = trade_date, 
                     op_exp = op_exp,call_prc = hi_wing_prc, short = FALSE, rf_rate = rf_rate)
      # add net pricing
      payoff$net_price = payoff$low_wing_price+payoff$body_price+payoff$high_wing_price    
      # assign spread name
      sprd_nom = paste0("+",lo_wing_strike,"c/-",body_strike,"c/+",hi_wing_strike,"c Long Butterfly")
    }
    
  }else{
    
    if(short){
      # create lower wing payoff
      payoff$low_wing_price = get_put_exp(payoff = payoff, op_strike =lo_wing_strike, put_prc = lo_wing_prc,short = TRUE)
      # create body payoff
      payoff$body_price = get_put_exp(payoff = payoff, op_strike =body_strike, put_prc = body_prc,short = FALSE)*2
      # create lower wing payoff
      payoff$high_wing_price = get_put_exp(payoff = payoff, op_strike =hi_wing_strike, put_prc = hi_wing_prc,short = TRUE)
      
      # get pricing before expiration
      payoff$PnL = get_put_pnl(payoff = payoff, op_strike = lo_wing_strike, ivol = ivol_lo_wng, trade_date = trade_date,
                               op_exp = op_exp, put_prc = lo_wing_prc, short = TRUE, rf_rate = rf_rate) + 
        get_put_pnl(payoff = payoff, op_strike = body_strike, ivol = ivol_body, trade_date = trade_date, 
                    op_exp = op_exp,put_prc = body_prc, short = FALSE, rf_rate = rf_rate)*2 + 
        get_put_pnl(payoff = payoff, op_strike = hi_wing_strike, ivol = ivol_hi_wng, trade_date = trade_date, 
                    op_exp = op_exp,put_prc = hi_wing_prc, short = TRUE, rf_rate = rf_rate)
      # add net pricing
      payoff$net_price = payoff$low_wing_price+payoff$body_price+payoff$high_wing_price    
      # assign spread name
      sprd_nom = paste0("-",lo_wing_strike,"p/+",body_strike,"p/-",hi_wing_strike,"p Short Butterfly")
    }else{
      # create lower wing payoff
      payoff$low_wing_price = get_put_exp(payoff = payoff, op_strike =lo_wing_strike, put_prc = lo_wing_prc,short = FALSE)
      # create body payoff
      payoff$body_price = get_put_exp(payoff = payoff, op_strike =body_strike, put_prc = body_prc,short = TRUE)*2
      # create lower wing payoff
      payoff$high_wing_price = get_put_exp(payoff = payoff, op_strike =hi_wing_strike, put_prc = hi_wing_prc,short = FALSE)
      
      # get pricing before expiration
      payoff$PnL = get_put_pnl(payoff = payoff, op_strike = lo_wing_strike, ivol = ivol_lo_wng, trade_date = trade_date,
                               op_exp = op_exp, put_prc = lo_wing_prc, short = FALSE, rf_rate = rf_rate) + 
        get_put_pnl(payoff = payoff, op_strike = body_strike, ivol = ivol_body, trade_date = trade_date, 
                    op_exp = op_exp,put_prc = body_prc, short = TRUE, rf_rate = rf_rate)*2 + 
        get_put_pnl(payoff = payoff, op_strike = hi_wing_strike, ivol = ivol_hi_wng, trade_date = trade_date, 
                    op_exp = op_exp,put_prc = hi_wing_prc, short = FALSE, rf_rate = rf_rate)
      # add net pricing
      payoff$net_price = payoff$low_wing_price+payoff$body_price+payoff$high_wing_price    
      # assign spread name
      sprd_nom = paste0("+",lo_wing_strike,"p/-",body_strike,"p/+",hi_wing_strike,"p Long Butterfly")
    }
    
  }
  
  # add plot
  highchart() %>%
    hc_add_series(data = payoff[payoff$net_price <= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="red") %>%
    hc_add_series(data = payoff[payoff$net_price >= 0,],hcaes(x = 'uPrc', y = 'net_price'), type = 'column',color="green") %>%
    hc_add_series(data = payoff , hcaes(x = 'uPrc', y = 'PnL'), type="line", color = 'gray') %>%
    hc_xAxis(plotLines = list(list(value = round(und_prc,2), width = 2, color = "black"))) %>%
    hc_title(text=paste0("$",und_sym," | ",sprd_nom, " | ", as.character(op_exp), " Exp"), align="center") %>%
    hc_subtitle(text=paste0("Breakeven Prices: ",scales::dollar(lo_be), " / ",scales::dollar(hi_be), " | Current Price: ",
                            scales::dollar(und_prc), " | Option Price: ",scales::dollar(sprd_cost))) %>%
    hc_legend(enabled = FALSE) %>%
    hc_yAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'PnL ($) at Expiration')) %>% 
    hc_xAxis(opposite = FALSE,labels = list(format = "${value}"), title = list(text = 'Spot Price ($) at Expiration')) %>% 
    hc_tooltip(pointFormat = '${point.y: ,.2f}')
}
