require("RSQLite");require("quantmod");require("pbapply");require("DBI");require("data.table")
# *********************************************************************************************
# *********************************************************************************************
ALL <- readRDS("ch4p2-4_ALL_opIV.rds")
# calculate/divide IV in deciles
DEC <- quantile(ALL$iv, seq(0,1,.10))
# select N days to expiration
SUB <- subset(ALL, ALL$days2Exp == 30) # <- Chang the number of days left to expiration
# Flag expirations where underlying price at expiration exceeded standard deviations
SUB$isInBand <- ifelse(SUB$prcAtExp > SUB$dn1Std & SUB$prcAtExp < SUB$up1Std, 1, 0)
# Split into deciles
q01 <- subset(SUB, SUB$iv > DEC["0%"] & SUB$iv <= DEC["10%"]);  q01$QQ <- 1
q02 <- subset(SUB, SUB$iv > DEC["10%"] & SUB$iv <= DEC["20%"]); q02$QQ <- 2
q03 <- subset(SUB, SUB$iv > DEC["20%"] & SUB$iv <= DEC["30%"]); q03$QQ <- 3
q04 <- subset(SUB, SUB$iv > DEC["30%"] & SUB$iv <= DEC["40%"]); q04$QQ <- 4
q05 <- subset(SUB, SUB$iv > DEC["40%"] & SUB$iv <= DEC["50%"]); q05$QQ <- 5
q06 <- subset(SUB, SUB$iv > DEC["50%"] & SUB$iv <= DEC["60%"]); q06$QQ <- 6
q07 <- subset(SUB, SUB$iv > DEC["60%"] & SUB$iv <= DEC["70%"]); q07$QQ <- 7
q08 <- subset(SUB, SUB$iv > DEC["70%"] & SUB$iv <= DEC["80%"]); q08$QQ <- 8
q09 <- subset(SUB, SUB$iv > DEC["80%"] & SUB$iv <= DEC["90%"]); q09$QQ <- 9
q10 <- subset(SUB, SUB$iv > DEC["90%"] & SUB$iv <= DEC["100%"]);q10$QQ <- 10
# combine Deciles
QQ<- rbind(q01,q02,q03,q04,q05,q06,q07,q08,q09,q10)
# below lower band
SUB[which(SUB$prcAtExp < SUB$dn1Std),]
# above upper band
SUB[which(SUB$prcAtExp > SUB$up1Std),]
# lowest decile stayed within +/- 1-STDEV
sum(q02$isInBand == 1)/nrow(q02)
# Highest decile stayed within +/- 1-STDEV
sum(q10$isInBand == 1)/nrow(q10)
# Median Premium
#lowest decile
median(q02$Mid)
# highest decile
median(q10$Mid)

median(q10$Mid)/median(q02$Mid)

# Median Theta
#lowest decile
median(q02$theta)
# highest decile
median(q10$theta)

# get the average range outside stdev on the top decile
OUTSIDE <- subset(q08,q08$isInBand == 0)
OUTSIDE$miss <- abs(OUTSIDE$prcAtExp - OUTSIDE$strike)

max(OUTSIDE[which(OUTSIDE$flag == "C"),"miss"])