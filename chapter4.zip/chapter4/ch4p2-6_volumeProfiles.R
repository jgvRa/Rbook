require("plyr");require("ggplot2");require("cowplot");require("quantmod")
# get data
ticker <- "AAPL"
STK <- getSymbols(ticker,from="2020-01-01", auto.assign = FALSE)
STK <- round(STK,2)
# find range
RANGE <- range(Hi(STK),Lo(STK))
# create buckets at $5 intervals
RANGE[1] <- round_any(RANGE[1],5, f=floor)
RANGE[2] <- round_any(RANGE[2],5, f=ceiling)
SEQ <- seq(RANGE[1],RANGE[2], by=5)
# aggregate volume by intervals
AGG = function(SEQ,STK){
  LENGTH <- 1:(length(SEQ)-1)
  OUT <- lapply(as.list(LENGTH), function(ii){
    # aggregate volume
    SUB <- subset(STK, as.numeric(Lo(STK)) >= as.numeric(SEQ[ii]) | as.numeric(Hi(STK)) >= as.numeric(SEQ[ii]))
    SUB <- subset(SUB, as.numeric(Lo(SUB)) < as.numeric(SEQ[ii+1]) | as.numeric(Hi(SUB)) < as.numeric(SEQ[ii+1]))
    # return as data frame
    RET <- as.data.frame(cbind(SEQ[ii],SEQ[ii+1],as.numeric(sum(Vo(SUB)))))
    colnames(RET) <- c("greaterThan","lessThan","Volume")
    RET
  })
  # row bind
  OUT <- as.data.frame(do.call(rbind,OUT))
  # return
  OUT
}
# test function
volProfile <- AGG(SEQ,STK)
# plot volume profile 
p1 <- ggplot(volProfile) + 
  geom_col(aes(x = Volume, y = lessThan), linewidth = 1, color = "darkblue", fill = "white",orientation="y") 
# convert xts to dataframe to plot
df <- data.frame(coredata(Cl(STK)),Date=index(STK))
colnames(df)[1] <-ticker
p2 <- ggplot(df) + geom_line(aes(x = Date, y = AAPL, color="red")) 
cowplot::plot_grid(p1,p2,labels = c("volProfile","stock"))
# ****************************************************************************************************************
# ****************************************************************************************************************
# ****************************************************************************************************************