require("quantmod");require("pbapply");require("RQuantLib");require("httr");require("rvest");require("dplyr");require("data.table");require("httr2")

# function to get ETF constituents
getConstituents = function(ticker){
  # req
  request <- request(paste0("https://www.barchart.com/etfs-funds/quotes/", ticker, "/constituents")) %>%
    req_headers(
      `:authority` = 'www.barchart.com',
      `:path` = '/etfs-funds/quotes/DIA/constituents',
      `User-Agent` = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
      `Accept` = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
      `Accept-Encoding` = 'gzip, deflate, br, zstd',
      `Accept-Language` = "en-US,en;q=0.5",
      `Cache-Control` = 'max-age=0',
      `Connection` = "keep-alive",
      `Priority` = 'u=0, i',
      `Referer` = 'https://www.barchart.com/stocks/quotes/DIA',
      `sec-ch-ua` = '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
      `sec-ch-ua-mobile` = '?0',
      `sec-ch-ua-platform` = "macOS",
      `sec-fetch-dest` = 'document',
      `sec-fetch-mode` = 'navigate',
      `sec-fetch-site` = 'same-origin',
      `sec-fetch-user` = '?1',
      `upgrade-insecure-requests` = 1
    ) %>%
    req_perform()
  
  # Parse response
  # data_raw <- resp_body_html(request)
  #data_raw %>% html_nodes("table") %>% html_table()
  
  data <- data_raw %>% html_nodes("table") %>% html_table()
  
  # convert into a data table
  data <- rbindlist(lapply(data_raw$data,"[[",6), fill = TRUE, use.names = TRUE) %>% suppressWarnings()
  # subset stocks only 
  data = subset(data,data$symbolType == 1)
  # trim data frame
  data = data[,1:3]
  # format percentages
  data$percent <- as.numeric(data$percent)/100
  # sort by weight
  data = data[order(data$percent, decreasing = TRUE),]
  # return data frame
  data
}
# assign ETF
ETF <- "DIA"
# get ETF constituents
CONST <- getConstituents(ticker=ETF)
# extract ETF tickers
tickers <- as.character(CONST$symbol)
# get constituent stock data and calculate gaps
DATA <- do.call(merge,pblapply(as.list(tickers),function(x){
  # get stock data
  tmp <- getSymbols(Symbols=x,auto.assign = FALSE,from="2017-12-31")
  # add column (shift Close column 1 period forward)
  tmp$prevClose <- Lag(Cl(tmp))
  # calculate % return (Open to previous Close)
  tmp$gapPct <- round(Op(tmp)/tmp$prevClose-1,4)
  # rename colname
  colnames(tmp)[ncol(tmp)] <- x
  # return gap percentage
  tmp[,ncol(tmp)]
}))
# check for gaps (daily)
# add a min. gap threshold 
gapIndex = function(DATA, thresh){
  # number of stocks above threshold
  upCount <- rowSums(DATA > thresh, na.rm = TRUE)
  # number of stocks below threshold
  dnCount <- rowSums(DATA < -thresh, na.rm = TRUE)
  # average gap percentage
  AVG <- round(rowMeans(DATA, na.rm = TRUE),4)
  # number of total stocks (per row)
  TOTAL <- ncol(DATA)
  # signal line
  upMinusdn <- round((upCount-dnCount)/TOTAL,4)
  # merge and reclass as XTS
  OUT <- reclass(cbind(upCount,dnCount, TOTAL,AVG,upMinusdn),match.to = DATA)
  # make Count as percentage
  OUT$upPct <- round(OUT$upCount/OUT$TOTAL,4)
  OUT$dnPct <- round(OUT$dnCount/OUT$TOTAL,4)
  # return XTS object
  OUT
}
# test function
OUT <- gapIndex(DATA=DATA,thresh = 0.01)
# get ETF data
etf <- getSymbols(ETF, from="2017-12-31",auto.assign = FALSE)
# merge gapIndex
etf <- merge(etf,OUT)
# add previous close forward
etf$prevPRC <- Lag(Cl(etf))
# *********************************************************************************
# *********************************************************************************
# function to get closing gap days + prices
# gapPct : gap percentage to test on constituents
getAvgGapClose = function(gapPct){
    tmp = subset(etf, etf$AVG >= gapPct | etf$AVG <= -gapPct)
    # pass in Dates 
    OUT <-  lapply(as.list(index(tmp)), function(dte){
      # extract close for each date
      PRC <- round(Cl(etf)[dte],2)
      # add average gap as pct (constituents)
      PRC$AVG <- as.numeric(tmp[,"AVG"][dte])
      # add direction (if gap down -> long [+1] OR gap up -> short [-1] )
      PRC$SIG <- ifelse(as.numeric(tmp[,"AVG"][dte]) < 0, 1,-1)
      # find out when the gap closed
      if(as.numeric(PRC$SIG) == 1){
        # start 1 day forward (so that same bar Hi is not triggered)
        newDTE <- advance(calendar = "UnitedStates/NYSE",dates = as.Date(dte), n=1,timeUnit = 0)
        # gap to fill
        PRC$gap2Fill <- round(as.numeric(etf[,"prevPRC"][dte]),2)
        # etf Prices where gap is closed
        iloc <- which(Hi(etf)[paste0(newDTE,"::")] > as.numeric(etf[,"prevPRC"][dte]))
        # if legth of iloc is 0... it means gap has not yet closed
        if(length(iloc) !=0){
          # add days to close
          PRC$days2Close <- iloc[1]
          # get price where gap is closed
          PRC$fillPRC <- round(as.numeric(Hi(etf)[paste0(newDTE,"::")][iloc[1]]),2)
          # add fill priced date
          fillDTE <- index(Hi(etf)[paste0(newDTE,"::")][iloc[1]])
          PRC <- as.data.frame(merge(as.character(index(PRC)),coredata(PRC)))
          PRC$fillDTE <- fillDTE
        }else{
          # add days to close
          PRC$days2Close <- NA
          # get price where gap is closed
          PRC$fillPRC <- NA
          # add fill priced date
          fillDTE <- NA
          PRC <- as.data.frame(merge(as.character(index(PRC)),coredata(PRC)))
          PRC$fillDTE <- NA
        }
        
      }else{
        # start 1 day forward (so that same bar Hi is not triggered)
        newDTE <- advance(calendar = "UnitedStates/NYSE",dates = as.Date(dte), n=1,timeUnit = 0)
        # gap to fill
        PRC$gap2Fill <- round(as.numeric(etf[,"prevPRC"][dte]),2)
        # etf Prices where gap is closed
        iloc <- which(Lo(etf)[paste0(newDTE,"::")] < as.numeric(etf[,"prevPRC"][dte]))
        # if legth of iloc is 0... it means gap has not yet closed
        if(length(iloc) !=0){
        # add days to close
        PRC$days2Close <- iloc[1]
        # get price where gap is closed
        PRC$fillPRC <- round(as.numeric(Lo(etf)[paste0(newDTE,"::")][iloc[1]]),2)
        # add fill priced date
        fillDTE <- index(Hi(etf)[paste0(newDTE,"::")][iloc[1]])
        PRC <- as.data.frame(merge(as.character(index(PRC)),coredata(PRC)))
        PRC$fillDTE <- fillDTE
        }else{
          # add days to close
          PRC$days2Close <- NA
          # get price where gap is closed
          PRC$fillPRC <- NA
          # add fill priced date
          fillDTE <- NA
          PRC <- as.data.frame(merge(as.character(index(PRC)),coredata(PRC)))
          PRC$fillDTE <- NA
        }
      }
     PRC
    })
    
    # row bind results
    do.call(rbind,OUT)
}
# test function
ALL <- getAvgGapClose(gapPct = 0.01)
# *********************************************************************************
# *********************************************************************************
