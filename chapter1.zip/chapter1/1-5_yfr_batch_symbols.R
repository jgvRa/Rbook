suppressPackageStartupMessages(require("quantmod"))
suppressPackageStartupMessages(require("timeDate"))
suppressPackageStartupMessages(require("lubridate"))
suppressPackageStartupMessages(require("yfR"))

# read in all ETF data
EXCH <- readRDS("ETFdbAll.rds")
# get list of all ETF symbols
tickers = as.character(EXCH$symbol)
# assign current date for save/get indexing
TODAY = Sys.Date()

cat("\nNow Getting all ETFS!")

# check if the file exists, otherwise pull from YFinance
if(!file.exists(paste0("yfr_etf_",format(TODAY,format="%Y%m%d"),".rds"))){
  # create a directory to cache data (avoids redownloading data if it is already available)
  if(!dir.exists('etf_cache')){dir.create("etf_cache")}

  # get batch data using yfr package
  yfr_stock = yf_get(tickers=tickers, first_date =TODAY %m-% lubridate::years(3), last_date =TODAY+1,
                     thresh_bad_data = 0.50,cache_folder = "etf_cache")
  # extract tickers missed
  tickers_missed = unique(yfr_stock$ticker)
  tickers_missed = tickers[!(tickers %in% tickers_missed)]
  # save full dataset as an RDS file
  saveRDS(yfr_stock, paste0("yfr_etf_",format(TODAY,"%Y%m%d"), ".rds"))
}