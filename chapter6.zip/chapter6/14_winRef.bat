@echo off
C:
PATH "C:\Program Files\R\R-4.4.0\bin\x64"
cd C:\Users\jgarr\Documents\R
Rscript cs_getRefTokenWindows.R
pause
