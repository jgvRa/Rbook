setwd("/Volumes/6TB/R")
source("loadStart.R")
suppressPackageStartupMessages(require("RQuantLib"))
suppressPackageStartupMessages(require("dplyr"))
suppressPackageStartupMessages(require("plyr"))
suppressPackageStartupMessages(require('scales'))
# KILL SWITCH
TRADE = TRUE
# add trade account number
trade_acct = new.env()
assign("acc", "**********", envir = trade_acct)

if(isBusinessDay(calendar="UnitedStates/NYSE", dates = Sys.Date()) & TRADE){
  # read in accounts + order history
  acc <- readRDS("cs_accounts.rds") 
  allOrdHist <- readRDS("hybridScoreOrders.rds")
  cat("\n\n")
  # print orders to close
  print(allOrdHist[,c("filledQuantity", "orderLegCollection.instrument.symbol", "orderLegCollection.instruction",
                      "orderActivityCollection.executionLegs.price", "ttc")])
  if(as.Date(allOrdHist$ttc)[1] == Sys.Date()){
    # split by account
    acc1_close = allOrdHist[allOrdHist$accountNumber == trade_acct$acc,]
    # ********************************************************************************************************************
    source("traderAPI.R")
    # close order at the market price
    if(nrow(acc1_close)>0){
      sellOrds1 = do.call(c, lapply(as.list(acc1_close$orderLegCollection.instrument.symbol), function(tic){
        ordNum = cs_placeSingleOrder(accNum = acc$hashValue[match(trade_acct$acc, table = acc$accountNumber)], 
                                     ticker = tic, side = "SELL",sess = "NORMAL", dur = "DAY", 
                                     ordType = "MARKET", qty = 1, aType = 'EQUITY')
      }))
    }
    # ********************************************************************************************************************
    # ********************************************************************************************************************
    cat("\n\nSell Orders Submitted!!!")
  }else{cat("\nNothing to Close today!!!")}
  # ********************************************************************************************************************
  cat("\nClosed Positions @ Schwab! EOS!!")
}else{
  cat("\nNot A Trading Day! EOS!!")
}
