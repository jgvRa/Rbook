setwd("/Volumes/6TB/R")
# *****************************************************************************
# variable assignment
ETF = "OEF"
TODAY <- Sys.Date()
TRADE_BAR = 10
CLOSE_BAR = 18 
NSTOCKS = 3
look_back = 1
# KILL SWITCH
trade_today = TRUE
trade_acct = new.env()
assign("acc", "*********", envir = trade_acct)
# *****************************************************************************
suppressPackageStartupMessages(require("quantmod"));suppressPackageStartupMessages(require("dplyr"))
suppressPackageStartupMessages(require("PerformanceAnalytics"))
suppressPackageStartupMessages(require("timeDate"));suppressPackageStartupMessages(require("lubridate"))
suppressPackageStartupMessages(require("RQuantLib"));suppressPackageStartupMessages(require("scales"))
suppressPackageStartupMessages(require("stringr"));suppressPackageStartupMessages(require("plyr"))
# remove files from previous run or create path in working envir
if(dir.exists(ETF)){
  tmp = file.remove(list.files(paste0(ETF),full.names = T))
}else{
  dir.create(paste0(ETF))
}
# source trader api functions
source("traderAPI.R")
# ***********************************************************************************************************************************************
# ***********************************************************************************************************************************************
# start ALGO if it is a trading day 
if(isBusinessDay(calendar="UnitedStates/NYSE",dates = TODAY)){
  IN = Sys.time()
  # grab all constituents
  tickers = gsub(" ","",readRDS(paste0(tolower(ETF),"_tickers.rds")))
  tickers = tickers[!str_detect(tickers, "[0-9]")]
  tickers = tickers[!(tickers %in% c('USD', ' ', '-','XTSLA'))]
  tickers = tickers[str_detect(tickers, pattern = "[A-Z]")]
  tickers = str_replace(tickers, pattern = "BRKB", replacement = "BRK/B")
  # ********************************************************************************************************************************************
  # save data
  cat('\n Getting Intraday OHLCV Bars...')
  data_dump = lapply(as.list(tickers), function(x){
    # x = "WASH"
    Sys.sleep(1)
    source("traderAPI.R")
    stk_ohlcv <- cs_getHistBars(symbol = x, periodType = "day",period = 10, frequencyType = "minute", 
                                freq = 15, asXTS = TRUE, needExtendedHoursData = FALSE, startDate = TODAY-50,
                                endDate = TODAY+1)
    head(stk_ohlcv)
    saveRDS(stk_ohlcv, paste0(ETF,"/",gsub("\\/","\\.",x),".rds"))
  })
  # save benchmark data
  source("traderAPI.R")
  stk_ohlcv <- cs_getHistBars(symbol = "SPY", periodType = "day",period = 10, frequencyType = "minute", 
                              freq = 15, asXTS = TRUE, needExtendedHoursData = FALSE, startDate = TODAY-50,
                              endDate = TODAY+1)
  saveRDS(stk_ohlcv,"bm_data.rds")
  cat("..done!")
  # ********************************************************************************************************************************************
  
  FACTOR = function(x,asOf,RANGE,RANGE52,barSize,bm){
    
    cat("\n",sprintf("%-6s - %10s - # %5d/%5d [%5s]",x,as.character(asOf),which(tickers==x),length(tickers),scales::percent(round(which(tickers==x)/length(tickers),4),accuracy = 0.01)))
    # ************************************************************
    # get stock data 
    stk_ohlcv <- readRDS(paste0(ETF,"/",x,".rds"))
    # # convert to desired interval
    # stk_ohlcv <- to.hours4(XTS=stk_ohlcv)
    
    # calculate daily returns
    stk_ret <- ROC(Cl(stk_ohlcv), type = "discrete")
    bm_ret  <- ROC(Cl(bm),type = "discrete")
    # fix NAs
    stk_ret[is.na(stk_ret)] <-0
    bm_ret[is.na(bm_ret)] <-0
    # Calulate BETA factor
    BETA <-  ifelse(is.na(PerformanceAnalytics::CAPM.beta.bull(Ra=stk_ret[RANGE], Rb = bm_ret[RANGE], Rf = 0)),
                    abs(PerformanceAnalytics::CAPM.beta(Ra=stk_ret[RANGE], Rb = bm_ret[RANGE], Rf = 0)),
                    PerformanceAnalytics::CAPM.beta.bull(Ra=stk_ret[RANGE], Rb = bm_ret[RANGE], Rf = 0))
    # Calculate Sharpe Ratio Factor
    SHARPE <- (mean(stk_ret[RANGE]) - mean(bm_ret[RANGE]))/sd(stk_ret[RANGE])
    # return latest dollar volume
    DVOL <- merge(Cl(stk_ohlcv),Vo(stk_ohlcv))
    DVOL$dvol <- Cl(stk_ohlcv)*Vo(stk_ohlcv)
    DVOL <- DVOL[RANGE]
    DVOL <- as.numeric(tail(DVOL$dvol,1))/mean(DVOL$dvol) #as.numeric(tail(Cl(stk_ohlcv),1))*as.numeric(tail(Vo(stk_ohlcv),1))
    # momentum - percent change over the RANGE period
    MOMO <- as.numeric(Cl(tail(stk_ohlcv[RANGE],1)))/as.numeric(Cl(head(stk_ohlcv[RANGE],1)))-1
    # subset the last 52-weeks
    wk52 <- stk_ohlcv[RANGE52]
    # highest Hi & lowest lo in 52-weeks
    MAX <- max(Hi(wk52[RANGE]))
    MIN <- min(Lo(wk52[RANGE]))
    LAST<- as.numeric(Cl(tail(wk52[RANGE],1)))
    WK52 <- (LAST-MIN)/(MAX-MIN)
    # find weekly accumulation dist.
    MAX <- max(tail(Hi(stk_ohlcv[RANGE]),5))
    MIN <- min(tail(Lo(stk_ohlcv[RANGE]),5))
    AD <- (LAST-MIN)/(MAX-MIN)
    # find max drawdown in RANGE
    DD <- min(PerformanceAnalytics::Drawdowns(R=stk_ret[RANGE]))
    # find VaR during RANGE
    ES <- ifelse(is.na(as.numeric(PerformanceAnalytics::ES(R=stk_ret[RANGE]))),0,as.numeric(PerformanceAnalytics::ES(R=stk_ret[RANGE]))) %>% suppressMessages()
    # find alpha during RANGE
    ALPHA <- as.numeric(PerformanceAnalytics::CAPM.alpha(Ra=stk_ret[RANGE],Rb = bm_ret[RANGE]))
    # find Active Premium: stock return minus benchmark ANnualized
    APREM <- (sum(ROC(Cl(stk_ohlcv)[RANGE], type = "continuous"),na.rm = T) - sum(ROC(Cl(bm)[RANGE], type = "continuous"),na.rm = T))*sqrt(252*barSize)
    # combine all as data frame
    df = data.frame(symbol = x, 
                    date   = as.character(asOf),
                    prc    = as.numeric(LAST),
                    upbeta = as.numeric(BETA),
                    sharpe = as.numeric(SHARPE),
                    volume = as.numeric(DVOL),
                    momo   = as.numeric(MOMO),
                    wk52   = as.numeric(WK52),
                    accd   = as.numeric(AD),
                    mindd  = as.numeric(DD),
                    es     = as.numeric(ES),
                    alpha  = as.numeric(ALPHA),
                    ra_rb = as.numeric(APREM)
    )
    #print(df)
    # return data frame
    df
  }
  getTechScores = function(asOf,tickers, dmo_days){
    # backtest range
    END   <- as.POSIXct(asOf, tz = "America/New_York")
    START <- as.POSIXct(gsub(as.Date(END),RQuantLib::advance(calendar = "UnitedStates/NYSE", dates = as.Date(END), n = -dmo_days, timeUnit = 0),END),tz = "America/New_York")
    # ************************************************************
    # get bm data 
    bm <- readRDS('bm_data.rds')
    # convert to desired interval
    # bm <- to.hours4(XTS=bm)
    # ************************************************************
    RANGE <- paste0(START,"/",END)
    #print(RANGE)
    # range for 13-week
    START52 <- as.POSIXct(gsub(as.Date(END),RQuantLib::advance(calendar = "UnitedStates/NYSE", dates = as.Date(START), n = -13,timeUnit = 1),END),tz = "America/New_York")
    RANGE52 <- paste0(START52,"/",END)
    #print(RANGE52)
    # for each stock return the factors to rank
    FACTORS = lapply(as.list(tickers), function(x){
      #Sys.sleep(1) #if((which(x == tickers) %% 120) == 0){Sys.sleep(1)}
      tmp <- try(FACTOR(x = x,asOf = END,RANGE=RANGE,RANGE52=RANGE52,barSize = 15, bm=bm), silent = T)
      if(inherits(tmp,'try-error')){tmp = NULL}
      tmp
    })
    FACTORS = FACTORS[lapply(FACTORS,length)>0]
    # row bind all values
    FACTORS = do.call(rbind, FACTORS)
    #print(FACTORS)
    # RANK all factors
    SCALE = 1/10
    RANKS <- as.data.frame(FACTORS)
    RANKS$upbetaRank <- rank(RANKS$upbeta)/nrow(RANKS)
    RANKS$sharpeRank <- rank(RANKS$sharpe)/nrow(RANKS)
    RANKS$volumeRank <- rank(RANKS$volume)/nrow(RANKS)
    RANKS$momoRank   <- rank(RANKS$momo)/nrow(RANKS)
    RANKS$wk52Rank   <- rank(RANKS$wk52)/nrow(RANKS)
    RANKS$accdRank   <- rank(RANKS$accd)/nrow(RANKS)
    RANKS$minddRank  <- rank(RANKS$mindd)/nrow(RANKS)
    RANKS$esRank     <- rank(RANKS$es)/nrow(RANKS)
    RANKS$alphaRank  <- rank(RANKS$alpha)/nrow(RANKS)
    RANKS$ra_rbRank  <- rank(RANKS$ra_rb)/nrow(RANKS)
    # assign a final score
    RANKS$techScore <- (RANKS$upbetaRank*SCALE+
                          RANKS$sharpeRank*SCALE+
                          RANKS$volumeRank*SCALE+
                          RANKS$momoRank*SCALE+
                          RANKS$wk52Rank*SCALE+
                          RANKS$accdRank*SCALE+
                          RANKS$minddRank*SCALE+
                          RANKS$esRank*SCALE+
                          RANKS$alphaRank*SCALE+
                          RANKS$ra_rbRank*SCALE
    )
    # multiply x 10 (SCALED)
    RANKS$techScore <- RANKS$techScore*10
    # rank Highest to Lowest
    RANKS <- RANKS[order(RANKS$techScore, decreasing = T),]
    # return data frame
    RANKS
  }
  saveTS = function(asOf){
    D <- format(asOf,"%Y%m%d")
    H <- format(asOf,"%H")
    M <- format(asOf,"%M")
    S <- format(asOf,"%S")
    paste0(D,H,M,S)
  }
  ## Get Factors for All Stocks
  DATES <- seq.Date(from=TODAY,to = RQuantLib::advance(calendar = "UnitedStates/NYSE", dates = as.Date(TODAY), n = 1, timeUnit = 0),  by = "1 day")
  DATES <- seq.POSIXt(from= as.POSIXct(paste0(DATES[1], " 09:30:00"), tz = "America/New_York"), 
                      to = as.POSIXct(paste0(DATES[length(DATES)], " 15:45:00"), tz = "America/New_York"), 
                      by = "15 mins")
  DATES <- DATES[isBusinessDay(calendar="UnitedStates/NYSE",dates = as.Date(DATES))]
  DATES  = DATES[format(DATES,"%H:%M:%S") >="09:30:00" & format(DATES,"%H:%M:%S") < "16:00:00"]
  
  # time to start
  tts = with_tz(DATES[TRADE_BAR],tzone = "America/Los_Angeles")
  # time to close 
  ttc = with_tz(DATES[TRADE_BAR + CLOSE_BAR + 1],tzone = "America/Los_Angeles") 
  # trade bar
  asOf = DATES[TRADE_BAR]
  
  tickers = gsub(".rds","",list.files(paste0(ETF)))
  cat("\nNow Getting Latest Tech Scores...")
  # get tech Scores for all stocks
  FACTORS <- getTechScores(asOf = asOf, tickers=tickers, dmo_days=look_back)
  # order by techscore highest to lowest
  FACTORS = FACTORS[order(FACTORS$techScore, decreasing = TRUE),]
  cat("..done!")
  # *****************************************************************************************************************************
  #                           Add fundamental data + calculate hybrid scores 
  # *****************************************************************************************************************************
  cat("\nAdding Fundamental Scores...")
  # read in Fundamentals
  YR <- format(Sys.Date(), "%Y")
  FILES <- list.files("/Volumes/6TB/TRADER_API/FUNDAMENTALS",full.names = T, pattern = paste0(YR,"+"))
  FILES = FILES[length(FILES)]
  # for current trader api files
  getHybridScores = function(FILE, lb, ETF, tScores){
    # read in file
    FUND <- readRDS(FILE)
    # stocks only
    FUND <- as.data.frame(subset(FUND,FUND$assetType == "EQUITY"))
    
    FUND$closePrice <- as.numeric(FUND$fundamental.marketCap)/as.numeric(FUND$fundamental.sharesOutstanding)*1e6
    FUND$getDate <- as.Date(gsub(".rds","",gsub("/Volumes/6TB/TRADER_API/FUNDAMENTALS/","",FILE)),format = "%Y%m%d")
    # subset columns
    COLS = c("fundamental.symbol","fundamental.pcfRatio","fundamental.grossMarginTTM", 
             "fundamental.netProfitMarginTTM","fundamental.operatingMarginTTM", "fundamental.returnOnEquity", 
             "fundamental.totalDebtToEquity","fundamental.epsChangePercentTTM", "fundamental.revChangeTTM",
             "fundamental.sharesOutstanding", "fundamental.marketCap","closePrice","getDate")
    
    reNamed = c("symbol", "pcfRatio", "grossMarginTTM", "netProfitMarginTTM", "operatingMarginTTM", "returnOnEquity", 
                "totalDebtToEquity", "epsChangePercentTTM", "revChangeTTM",  "sharesOutstanding", "marketCap",  
                "closePrice","getDate")
    # subset columns
    FUND = FUND[,COLS]
    colnames(FUND) = reNamed
    # fix market cap
    #FUND$marketCap <- FUND$marketCap*1e+06
    # fix symbol
    FUND$symbol = gsub("/",".",FUND$symbol)
    # isolate FUND
    FUND <- subset(FUND, FUND$pcfRatio >0)
    FUND <- subset(FUND, FUND$grossMarginTTM > 0)
    FUND <- subset(FUND, FUND$operatingMarginTTM > 0)
    FUND <- subset(FUND, FUND$netProfitMarginTTM > 0)
    FUND <- subset(FUND, FUND$returnOnEquity > 0)
    FUND <- subset(FUND, FUND$revChangeTTM > 0)
    FUND <- subset(FUND, FUND$epsChangePercentTTM > 0)
    # calculate cash flow
    FUND$cfo <- (FUND$closePrice/FUND$pcfRatio)*(FUND$sharesOutstanding/1e+06)
    # get start/end dates
    DATES <- seq.Date(from=as.Date(FUND$getDate[1]),to =as.Date(FUND$getDate[1])+10, "1 day")
    START <- DATES[which(weekdays(DATES,abbreviate = T) == "Mon")[1]]
    END <- DATES[which(weekdays(DATES,abbreviate = T) == "Fri")[2]]
    COLS = c("symbol", "grossMarginTTM", "netProfitMarginTTM", "operatingMarginTTM", "returnOnEquity", "totalDebtToEquity", 
             "epsChangePercentTTM", "revChangeTTM", "sharesOutstanding", "marketCap", "cfo")
    FUND = FUND[,COLS]
    # ******************************************************************************************************************************************
    # ******************************************************************************************************************************************
    # get all tech scores
    tech_scores = tScores[,c("symbol","date","prc","techScore")]
    # unique stocks
    stks_tech <- unique(tech_scores$symbol)
    stks_fund <- unique(FUND$symbol)
    stks <- stks_fund[stks_fund %in% stks_tech]
    # subset to availability
    FUND <- FUND[FUND$symbol %in% stks,]
    tech_scores <- tech_scores[tech_scores$symbol %in% stks,]
    # rank FUND
    FUND$grossMarginTTMr <- rank(FUND$grossMarginTTM)/nrow(FUND)
    FUND$netProfitMarginTTMr <- rank(FUND$netProfitMarginTTM)/nrow(FUND)
    FUND$operatingMarginTTMr <- rank(FUND$operatingMarginTTM)/nrow(FUND)
    FUND$returnOnEquityr <- rank(FUND$returnOnEquity)/nrow(FUND)
    FUND$totalDebtToEquityr <- rank(-FUND$totalDebtToEquity)/nrow(FUND)
    FUND$epsChangePercentTTMr<-rank(FUND$epsChangePercentTTM)/nrow(FUND)
    FUND$revChangeTTMr <- rank(FUND$revChangeTTM)/nrow(FUND)
    FUND$cfor <- rank(FUND$cfo/FUND$sharesOutstanding)/nrow(FUND)
    # assign a final score
    SCALE <- 1/8
    FUND$fundScore <- (FUND$grossMarginTTMr*SCALE+
                         FUND$netProfitMarginTTMr *SCALE+
                         FUND$operatingMarginTTMr*SCALE+
                         FUND$returnOnEquityr*SCALE+
                         FUND$totalDebtToEquityr*SCALE+
                         FUND$epsChangePercentTTMr*SCALE+
                         FUND$revChangeTTMr*SCALE+
                         FUND$cfor*SCALE
    )
    FUND$fundScore <- FUND$fundScore * 8
    # add to tech scores
    tech_scores$fundScore <- FUND$fundScore[match(tech_scores$symbol, table = FUND$symbol)]
    # calculate hybrid scores
    tech_scores$hybridScore <- (tech_scores$techScore*0.70)+(tech_scores$fundScore*0.30)
    # add market caps
    tech_scores$sharesOut <- FUND$sharesOutstanding[match(tech_scores$symbol, table = FUND$symbol)]
    tech_scores$marketCap <- tech_scores$prc*tech_scores$sharesOut
    # order highest to lowest
    tech_scores = tech_scores[order(tech_scores$hybridScore, decreasing = T),]
    # limit columns
    tech_scores = tech_scores[,c('symbol','date','prc','techScore','fundScore','hybridScore')]
    # return hybrid scores
    tech_scores
  }
  # calculate bar hybrid scores
  hybrid_scores = getHybridScores(FILE = FILES, lb = look_back, ETF = ETF, tScores = FACTORS)
  cat("..done!")
  # subset top N-stocks
  stks2trade =  hybrid_scores[1:NSTOCKS,]
  # fix BRK.B to BRK/B for trading
  stks2trade$symbol = str_replace(stks2trade$symbol, pattern = "BRK.B", replacement = "BRK/B")
  # print the top results to trade
  cat("\n\nStocks To Trade Today:\n")
  print(stks2trade,row.names = F)
  cat("\nClose at: ",paste(ttc))
  # check if user wants to trade today
  if(trade_today){
    
    # **************************************************************************************************************
    #                         trade stocks / open positions
    # **************************************************************************************************************
    # read in accounts with acc Nums and hashValue
    # acc = structure(list(accountNumber = c("1234324", "123123123", "4312312343"
    # ), hashValue = c("AOSPDFNAWEFAJIASJFOASA@#r012304902394030249KOJGDFJSDFGIOJE43R0SA",
    #                  "FDOKASE309FAS6ASR56A5FSD65AERFDASER5FACS6DF5AFSFD5AS6DF5ADSFDSDR",
    #                  "ASDFIOJ3OQTDFS654FAW6EACWEFDA3TSDFG4S5DFGASE6F6DASF5GFDSGDF64GFD"
    # )), row.names = c(NA, -3L), class = "data.frame")
    
    acc <- readRDS("cs_accounts.rds")
    # subset to trade account only
    iloc = which(acc$accountNumber == trade_acct$acc)
    acc = acc[iloc,]
    cat("\nSending Orders...")
    # try to open positions
    source("traderAPI.R")
    # send ORDERS for trade account:
    if(nrow(stks2trade)>0){
      allOrds1 = do.call(c, lapply(as.list(stks2trade$symbol), function(tic){
        ordNum = cs_placeSingleOrder(accNum = acc$hashValue[1], ticker = tic, side = "BUY",
                                     sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
      }))
    }
    cat("done!")
    # ************************************************************************************************************************************************************************
    # sleep for a couple seconds to get order history
    Sys.sleep(5)
    ordHist1 = cs_getOrders(accNum = acc$hashValue[1],maxResults = 25, fromEnteredTime = TODAY-1,toEnteredTime =  TODAY+1,status = NULL)
    # combine order history
    allOrdHist = ordHist1
    # combine order ID's
    allOrds = allOrds1
    # match up the orders ids to the ones in the order history
    allOrdHist = allOrdHist[match(allOrds, table = allOrdHist$orderId),]
    # subset where filled quantity is > 1
    allOrdHist = subset(allOrdHist, allOrdHist$filledQuantity > 0)
    # add time to close (ttc)
    allOrdHist$ttc = ttc
    # save these orders as we will have to close the following day
    saveRDS(allOrdHist, "hybridScoreOrders.rds")
    # calculate the algo run time 
    OUT = Sys.time()
    TOTAL_TIME = OUT-IN
    UNITS = units(TOTAL_TIME)
    cat("\n\n")
    # print total time
    cat(sprintf("%-15s: %-5s %-5s","Total Algo Time", round(TOTAL_TIME,3), UNITS))
  }else{cat("\nNo Trading Today! :/")}
  # END OF ALGO
  cat("\n\n Algo Done!")
}else{
  cat("\nNot A Business Day!! - End-Of-Script!!!")
}