setwd("/Volumes/6TB/R")
require("jsonlite");require("data.table");require("pbapply");require("RQuantLib");require("lubridate");require("httr");require("dplyr")

cat("\nNow Getting CS Fundamentals!!")

PASS <- new.env()
assign("usrAgent","mywebsite.com myemail@gmail.com",env=PASS)
# ************************************************************************************************************************************************************
# ************************************************************************************************************************************************************
# GET request for tickers
land_page = GET(url= "https://www.sec.gov/files/company_tickers.json",
                config = httr::add_headers(`User-Agent` = PASS$usrAgent,
                                           `Accept-Encoding` = 'gzip, deflate'))
# rowbind results
INFO = rbindlist(content(land_page)) %>% as.data.frame()
tickers <- INFO$ticker
# load all equity symbols
spy <- readRDS("spy_tickers.rds")
qqq <- gsub(" ","",readRDS('qqq_tickers.rds'))
dia <- readRDS('dia_tickers.rds')
mdy <- readRDS('mdy_tickers.rds')
iwm <- readRDS('iwm_tickers.rds')
idx <- readRDS('index_tickers.rds')
etfs<- readRDS('ETFdbAll.rds')
etfs <- as.character(unique(etfs$symbol))
tickers <- unique(c(spy,qqq,dia,mdy,iwm,etfs,tickers));rm(spy,qqq,dia,mdy,iwm,etfs)
tickers <- gsub("\\.","/",tickers)
tickers <- gsub("\\-","/",tickers)
source("/Volumes/6TB/R/traderAPI.R")
# ****************************************************
#                 EQT Fundamentals
# ****************************************************
# get Fundamental Data for EQT
eqtDF = lapply(as.list(1:length(tickers)), function(x){
  # sleep 1 minute : rate limit 120/minute
  if((x %% 120) == 0){Sys.sleep(60)} 
  # get the ticker
  ticker = tickers[x]
  cat("\nNow Getting Symbol: ",ticker," ",which(ticker == tickers),"/",length(tickers),"[",round(which(ticker == tickers)/length(tickers),4)*100,"%]")
  # get Fundamental data
  tmp = try(cs_getInstruments(symbol = ticker,projection = "fundamental"),silent = TRUE)
  # will avoid breaking if error
  if(!inherits(tmp,'try-error')) tmp
})
# complete cases only
eqtDF = eqtDF[lapply(eqtDF,length)>1] 
# rbind all
eqtDF = as.data.frame(rbindlist(eqtDF,use.names = TRUE, fill = TRUE) )
# omit any NAs for symbols
eqtDF = eqtDF[!is.na(eqtDF$fundamental.symbol)]
# save DF
cat("\nNow Saving CS Fundamentals!!")
saveRDS(eqtDF,paste0("/Volumes/6TB/TRADER_API/FUNDAMENTALS/",format(advance(calendar = "UnitedStates/NYSE",dates = Sys.Date(), n=-1,timeUnit = 0),"%Y%m%d"),".rds"))   
cat("\nTotal # of Stocks: ",length(unique(eqtDF$symbol)))

