setwd("....YOUR WORKING DIRECTORY....")
require("jsonlite");require("quantmod");require("pbapply"); require("data.table");require("DBI");require("odbc");require("RSQLite");
require("scales");require("httr");require("dplyr")
# source trader All API functions
source("TraderAPI.R")
cat("\nNow getting Volume Data...")
PASS <- new.env()
assign("usrAgent","inser_web_site insert_email",env=PASS)
# ************************************************************************************************************************************************************
#                           Get ticker Symbols 
# ************************************************************************************************************************************************************
# GET request for all links in landing page
land_page = GET(url= "https://www.sec.gov/files/company_tickers.json",
                config = httr::add_headers(`User-Agent` = PASS$usrAgent,
                                           `Accept-Encoding` = 'gzip, deflate'))
INFO = rbindlist(content(land_page)) %>% as.data.frame()
tickers <- INFO$ticker
# read in ETF data from CBOE
ETFS <- read.csv("https://www.cboe.com/us/equities/market_statistics/listed_symbols/csv/",header = TRUE,sep = ",")
ETFS <- as.character(ETFS$Name)

all_symbols <- read.csv('https://www.cboe.com/us/options/symboldir/equity_index_options/?download=csv',sep=",")
all_symbols <- as.character(all_symbols$Stock.Symbol)
tickers <- unique(c(tickers,ETFS,all_symbols))
tickers = gsub("\\-","/",tickers)
tickers = gsub("\\.","/",tickers)
tickers = unique(tickers)

cat("...done!\n# of tickers: ",length(tickers))
cat("\nNow getting intraday stock data...")
# ************************************************************************************************************************************************************
#                                           Request API Data
# ************************************************************************************************************************************************************
data <- lapply(as.list(1:length(tickers)), function(x){
  cat("\n",sprintf("%-8s - # %5d/%5d [%5s]",tickers[x],x,length(tickers),scales::percent(round(x/length(tickers),4),accuracy = 0.01)))
  if((x %% 120) == 0){Sys.sleep(60)}
  tmp <- try(cs_getHistBars(symbol = tickers[x],periodType = "day", period = 10, frequencyType = "minute",freq = 1,
                            needExtendedHoursData = TRUE,asXTS = FALSE),silent = TRUE)
  if(!inherits(tmp,'try-error')){tmp}
})
cat("done")

data = data[lapply(data,length)>0]
data = rbindlist(data,use.names = TRUE,fill = TRUE)
# ******************************************************************************************************************************
# ******************************************************************************************************************************
GOT = as.character(unique(data$symbol))
cat("\n GOT: ",length(GOT), " out of ", length(tickers), "[",round(length(GOT)/length(tickers),4)*100,"%]")
# ******************************************************************************************************************************
# ******************************************************************************************************************************
cat("\nNow saving data...")
# save locally as an RDS file
saveRDS(data,paste0("/Volumes/6TB/TRADER_API/OHLCV/",format(Sys.Date(),"%Y%m%d"),".rds"))
cat("done\n")
cat("\nNow saving data...")
cat("\nTotal # of tickers: ",length(unique(data$symbol)))
cat("\nMin Date          : ",paste(as.POSIXct(min(data$datetime)/1000,tz = "America/New_York")))
cat("\nMax Date          : ",paste(as.POSIXct(max(data$datetime)/1000,tz = "America/New_York")))
# ****************************************************************************************************************************
# # Write data to database - SQLite - * Must provide a path/location in dbConnect() to save 
cat("\n\nNow writing to DB: ")
TYPES= c(open="double(10,2)",high="double(10,2)",low ="double(10,2)", close ="double(10,2)", volume="Int(25)", datetime="Int", symbol="varchar(10)")
driver = dbDriver("SQLite")
con = dbConnect(driver, dbname = paste0("/Volumes/3TB/SQLite/IntraStkCS.db"))
dbWriteTable(con,name="IntraStkCS",value=as.data.frame(data),append=TRUE,overwrite=FALSE)
dbDisconnect(con)
cat("\n\nFinito!!!")


# 
# getSymbolsIntra = function(stk){
#   # establish DB connection
#   driver = dbDriver("SQLite")
#   con = dbConnect(driver, dbname = paste0("/Volumes/3TB/SQLite/IntraStkCS.db"))
#   tmp <- as.data.frame(dbGetQuery(con,paste0("SELECT * FROM IntraStkCS WHERE symbol = '",stk,"';")))
#   dbDisconnect(con)
#   # convert to xts
#   tmp <- unique(tmp)
#   timeStamp <- as.POSIXct(tmp$datetime/1000, tz="America/New_York",origin="1970-01-01")
#   toXTS <- xts(tmp[,c("open","high","low","close","volume")], order.by = timeStamp)
#   colnames(toXTS) = c("Open","High","Low","Close","Volume")
#   # make index unique
#   toXTS <- make.index.unique(toXTS, drop=TRUE, fromLast = TRUE)
#   # change column names
#   colnames(toXTS) <- paste0(stk,".",names(toXTS))
#   # return data
#   toXTS
# }
# 
# stk_data = getSymbolsIntra(stk="MARA")
