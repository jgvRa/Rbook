setwd("/Volumes/6TB/R")
suppressPackageStartupMessages(require("httr"))
suppressPackageStartupMessages(require("stringr"))
suppressPackageStartupMessages(require("RCurl"))
suppressPackageStartupMessages(require("lubridate"))
suppressPackageStartupMessages(require("data.table"))
## Asign Keys
# we will assign app_key & secret in new environment to keep it hidden
pw = new.env()
assign("app_key","ENTER_APP_KEY_HERE",envir = pw)
assign("secret","ENTER_SECRET_HERE",envir = pw)
# assign redirect URL
redirect_url = 'https://127.0.0.1'

## Step 1 - Create URL + Authenticate Online
# function to create URL
cs_login_auth = function(app_key,redirect_url){paste0('https://api.schwabapi.com/v1/oauth/authorize?&client_id=',app_key,'&redirect_uri=',redirect_url)}
# Prints URL 
cat("\nEnter this on the web browser: ", cs_login_auth(app_key = pw$app_key, redirect_url = redirect_url))

cat("\n\nNow Enter the Response URL: ")
#respURL <- readline(prompt = "Now Enter the Response URL: ")
respURL <- scan("stdin", character(), n=1)
cat("\n\nYou Entered: ", respURL)
## Step 2 - Extract Code From URL
# function to grab code from URL
get_cs_code = function(respURL){paste0(str_sub(respURL, start = str_locate(respURL,pattern = "code=")[2]+1,end=str_locate(respURL,pattern = "%40&")[1]-1), "@")}
# assign code
cs_code <- get_cs_code(respURL)

## Step 3 - Get Initial 7-day Token
# get initial tokens - every 7 days
generate_tokens = function(app_key, secret, cs_code, redirect_url){
  # url to authenticate
  URL = 'https://api.schwabapi.com/v1/oauth/token'
  # add payload
  payload = list('grant_type'='authorization_code',
                 'code'= cs_code,
                 'redirect_uri'= redirect_url)
  # make post request
  pg <- httr::POST(url=URL,
                   body = payload,
                   httr::add_headers(`Authorization` = paste0("Basic ",base64Encode(paste0(app_key,":",secret))[1]),
                                     `Content-Type` = 'application/x-www-form-urlencoded'),
                   encode="form" #,httr::verbose()
  )
  if(httr::status_code(pg) == 200){
    # run time - renew time
    got_time = as.POSIXct(pg[["date"]],tz = Sys.timezone())
    # extract page contents
    resp <- httr::content(pg)
    # A Trader API access token is valid for 30 minutes. A Trader API refresh token is valid for 7 days.
    resp <- c(resp,
              list(access_token_exp = got_time + minutes(30),
                   refresh_token_exp = got_time + days(7)))
    # save tokens locally (in working directory)
    saveRDS(resp,"cs_tokens.rds")
  }else{
    cat("\nError In Authentication: Check your app_key, secret, cs_code, & redirect_url")
    resp <- NULL
  }
  # return response
  resp
}
# ***********************************************************************************************************************
# ***********************************************************************************************************************
# get initial tokens
resp <- generate_tokens(app_key = pw$app_key, secret = pw$secret, cs_code = cs_code,redirect_url = redirect_url)

cat("\n\nSaved in: ", getwd())
print(resp)

