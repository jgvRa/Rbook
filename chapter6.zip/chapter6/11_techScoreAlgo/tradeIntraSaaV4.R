setwd("/Volumes/6TB/R")
suppressPackageStartupMessages(require("quantmod"));suppressPackageStartupMessages(require("dplyr"))
suppressPackageStartupMessages(require("PerformanceAnalytics"))
suppressPackageStartupMessages(require("timeDate"));suppressPackageStartupMessages(require("lubridate"))
suppressPackageStartupMessages(require("RQuantLib"));suppressPackageStartupMessages(require("scales"))
suppressPackageStartupMessages(require("yfR"));suppressPackageStartupMessages(require("DBI"))
suppressPackageStartupMessages(require("stringr"));suppressPackageStartupMessages(require("plyr"))
source("traderAPI.R")
TODAY <- Sys.Date()
TRADE_BAR = 10
CLOSE_BAR = 3
NSTOCKS = 2
# file.edit('technicalRanks.R')
if(isBusinessDay(calendar="UnitedStates/NYSE",dates = TODAY)){
  # grab all constituents
  tickers = gsub(" ","",readRDS("qqq_tickers.rds"))
  ## BackTest Function
  # Create Technical Score Ranking System Based on the following factors:
  # 1. `Beta`            - Rank stocks using Upside Beta given a 3-month window
  # 2. `Sharpe Ratio`    - Assign ranks to sharpe ratio given a 3-month window
  # 3. `Rel Vol Volume`  - We will use a dollar volume rank relative to its 3-month period
  # 4. `Momentum`        - Rank stocks showing greater momentum in the past 3-months
  # 5. `52-wk Range`     - Where is the stock trading relative to their 52-week range
  # 6. `Week A/C`        - In the past 5 sessions (week), rank by accumulation distribution (stock price relative to weekly range)
  # 7. `DrawDowns`       - Ranks stocks by drawdowns, we want to penalize large downside moves
  # 8. `VaR`             - Value-At-Risk, How much can a stock lose on any given day
  # 9. `Alpha`           - Calculate CAPM Alpha during the 3-month window
  # 10. `Active Premium` - Asset's return minus benchmark return
  
  #'@param asOf    - Date to use as the last date for calculation purposes (format : "2024-01-31")
  #'@param tickers - vector of ticker symbols to use (format : c("MSFT","AAPL,"AMZN"))
  FACTOR = function(x,asOf,RANGE,RANGE52,barSize,bm){
    source("traderAPI.R")
    cat("\n",sprintf("%-6s - %10 s-# %5d/%5d [%5s]",x,as.character(asOf),which(tickers==x),length(tickers),scales::percent(round(which(tickers==x)/length(tickers),4),accuracy = 0.01)))
    # get stock data 
    if(!exists(x, envir = e)){
      stk_ohlcv <- cs_getHistBars(symbol = x, periodType = "day",period = 10, frequencyType = "minute", freq = 15, asXTS = TRUE, needExtendedHoursData = FALSE,endDate = as.Date(asOf)+1)
      assign(x, stk_ohlcv, envir = e)
    }else{
      stk_ohlcv <- get(x=x, envir = e)
    }
    # calculate daily returns
    stk_ret <- ROC(Cl(stk_ohlcv), type = "discrete")
    bm_ret  <- ROC(Cl(bm),type = "discrete")
    # fix NAs
    stk_ret[is.na(stk_ret)] <-0
    bm_ret[is.na(bm_ret)] <-0
    # Calulate BETA factor
    BETA <- PerformanceAnalytics::CAPM.beta.bull(Ra=stk_ret[RANGE], Rb = bm_ret[RANGE])
    # Calculate Sharpe Ratio Factor
    SHARPE <- (mean(stk_ret[RANGE]) - mean(bm_ret[RANGE]))/sd(stk_ret[RANGE])
    # return latest dollar volume
    DVOL <- merge(Cl(stk_ohlcv),Vo(stk_ohlcv))
    DVOL$dvol <- Cl(stk_ohlcv)*Vo(stk_ohlcv)
    DVOL <- DVOL[RANGE]
    DVOL <- as.numeric(tail(DVOL$dvol,1))/mean(DVOL$dvol) #as.numeric(tail(Cl(stk_ohlcv),1))*as.numeric(tail(Vo(stk_ohlcv),1))
    # momentum - percent change over the RANGE period
    MOMO <- as.numeric(Cl(tail(stk_ohlcv[RANGE],1)))/as.numeric(Cl(head(stk_ohlcv[RANGE],1)))-1
    # subset the last 52-weeks
    wk52 <- stk_ohlcv[RANGE52]
    # highest Hi & lowest lo in 52-weeks
    MAX <- max(Hi(wk52[RANGE]))
    MIN <- min(Lo(wk52[RANGE]))
    LAST<- as.numeric(Cl(tail(wk52[RANGE],1)))
    WK52 <- (LAST-MIN)/(MAX-MIN)
    # find weekly accumulation dist.
    MAX <- max(tail(Hi(stk_ohlcv[RANGE]),5))
    MIN <- min(tail(Lo(stk_ohlcv[RANGE]),5))
    AD <- (LAST-MIN)/(MAX-MIN)
    # find max drawdown in RANGE
    DD <- min(PerformanceAnalytics::Drawdowns(R=stk_ret[RANGE]))
    # find VaR during RANGE
    ES <- ifelse(is.na(as.numeric(PerformanceAnalytics::ES(R=stk_ret[RANGE]))),0,as.numeric(PerformanceAnalytics::ES(R=stk_ret[RANGE]))) %>% suppressMessages()
    # find alpha during RANGE
    ALPHA <- as.numeric(PerformanceAnalytics::CAPM.alpha(Ra=stk_ret[RANGE],Rb = bm_ret[RANGE]))
    # find Active Premium: stock return minus benchmark ANnualized
    APREM <- (sum(ROC(Cl(stk_ohlcv)[RANGE], type = "continuous"),na.rm = T) - sum(ROC(Cl(bm)[RANGE], type = "continuous"),na.rm = T))*sqrt(252*barSize)
    # combine all as data frame
    df = data.frame(symbol = x, 
                    date   = as.character(asOf),
                    prc    = as.numeric(LAST),
                    upbeta = as.numeric(BETA),
                    sharpe = as.numeric(SHARPE),
                    volume = as.numeric(DVOL),
                    momo   = as.numeric(MOMO),
                    wk52   = as.numeric(WK52),
                    accd   = as.numeric(AD),
                    mindd  = as.numeric(DD),
                    es     = as.numeric(ES),
                    alpha  = as.numeric(ALPHA),
                    ra_rb = as.numeric(APREM)
    )
    #print(df)
    # return data frame
    df
  }
  getTechScores = function(asOf,tickers, dmo_days){
    source("traderAPI.R")
    # backtest range
    END   <- as.POSIXct(asOf, tz = "America/New_York")
    START <- as.POSIXct(gsub(as.Date(END),RQuantLib::advance(calendar = "UnitedStates/NYSE", dates = as.Date(END), n = -dmo_days, timeUnit = 0),END),tz = "America/New_York")
    if(!exists('bm' ,envir = e)){
      bm = cs_getHistBars(symbol = "SPY", periodType = "day",period = 10, frequencyType = "minute", freq = 15, asXTS = TRUE, needExtendedHoursData = FALSE,endDate = as.Date(asOf)+1)
      bm = bm["T0930/T1559"]
      assign('bm', bm, envir = e)
    }else{
      bm <- get('bm', envir = e)
    }
    
    RANGE <- paste0(START,"/",END)
    #print(RANGE)
    # range for 1-week
    START52 <- as.POSIXct(gsub(as.Date(END),RQuantLib::advance(calendar = "UnitedStates/NYSE", dates = as.Date(START), n = -1,timeUnit = 1),END),tz = "America/New_York")
    RANGE52 <- paste0(START52,"/",END)
    #print(RANGE52)
    # for each stock return the factors to rank
    FACTORS = lapply(as.list(tickers), function(x){
      Sys.sleep(1) #if((which(x == tickers) %% 120) == 0){Sys.sleep(1)}
      tmp <- try(FACTOR(x = x,asOf = END,RANGE=RANGE,RANGE52=RANGE52,barSize = 15, bm=bm), silent = T)
      if(inherits(tmp,'try-error')){tmp = NULL}
      tmp
    })
    FACTORS = FACTORS[lapply(FACTORS,length)>0]
    # row bind all values
    FACTORS = do.call(rbind, FACTORS)
    #print(FACTORS)
    # RANK all factors
    SCALE = 1/10
    RANKS <- as.data.frame(FACTORS)
    RANKS$upbetaRank <- rank(RANKS$upbeta)/nrow(RANKS)
    RANKS$sharpeRank <- rank(RANKS$sharpe)/nrow(RANKS)
    RANKS$volumeRank <- rank(RANKS$volume)/nrow(RANKS)
    RANKS$momoRank   <- rank(RANKS$momo)/nrow(RANKS)
    RANKS$wk52Rank   <- rank(RANKS$wk52)/nrow(RANKS)
    RANKS$accdRank   <- rank(RANKS$accd)/nrow(RANKS)
    RANKS$minddRank  <- rank(RANKS$mindd)/nrow(RANKS)
    RANKS$esRank     <- rank(RANKS$es)/nrow(RANKS)
    RANKS$alphaRank  <- rank(RANKS$alpha)/nrow(RANKS)
    RANKS$ra_rbRank  <- rank(RANKS$ra_rb)/nrow(RANKS)
    # assign a final score
    RANKS$techScore <- (RANKS$upbetaRank*SCALE+
                          RANKS$sharpeRank*SCALE+
                          RANKS$volumeRank*SCALE+
                          RANKS$momoRank*SCALE+
                          RANKS$wk52Rank*SCALE+
                          RANKS$accdRank*SCALE+
                          RANKS$minddRank*SCALE+
                          RANKS$esRank*SCALE+
                          RANKS$alphaRank*SCALE+
                          RANKS$ra_rbRank*SCALE
    )
    # multiply x 10 (SCALED)
    RANKS$techScore <- RANKS$techScore*10
    # rank Highest to Lowest
    RANKS <- RANKS[order(RANKS$techScore, decreasing = T),]
    # return data frame
    RANKS
  }
  ## Get Factors for All Stocks
  DATES <- seq.Date(from=TODAY,to = TODAY, by = "1 day")
  DATES <- seq.POSIXt(from= as.POSIXct(paste0(DATES[1], " 09:30:00"), tz = "America/New_York"), 
                      to = as.POSIXct(paste0(DATES[length(DATES)], " 15:45:00"), tz = "America/New_York"), 
                      by = "15 mins")
  DATES <- DATES[isBusinessDay(calendar="UnitedStates/NYSE",dates = as.Date(DATES))]
  DATES  = DATES[format(DATES,"%H:%M:%S") >="09:30:00" & format(DATES,"%H:%M:%S") < "16:00:00"]
  
  # time to start
  tts = with_tz(DATES[TRADE_BAR],tzone = "America/Los_Angeles")
  # time to close 
  ttc = with_tz(DATES[TRADE_BAR + CLOSE_BAR + 1],tzone = "America/Los_Angeles") # technically at the 13th close
  # trade bar
  asOf = DATES[TRADE_BAR]
  # create new environment to store OHLCV data  
  e <- new.env()
  # get tech Scores for all stocks
  FACTORS_3DY <- getTechScores(asOf = asOf, tickers=tickers, dmo_days=3)
  # order by techscore highest to lowest
  FACTORS_3DY = FACTORS_3DY[order(FACTORS_3DY$techScore, decreasing = TRUE),]
  # subset top 2-stocks
  FACTORS_3DY = FACTORS_3DY[1:NSTOCKS,]
  # print the top results to trade
  cat("\n\n")
  stks2trade = FACTORS_3DY[,c("symbol","date","prc","techScore")]
  print(stks2trade,row.names = F)
  cat("\nClose at: ",paste(ttc))
  # **************************************************************************************************************
  #                         trade stocks / open positions
  # **************************************************************************************************************
  # get account balances
  acc_bal = cs_getAccPos(field='positions')
  # read in accounts
  acc <- readRDS("cs_accounts.rds")
  # assign cash available for each account
  ilocs = match(acc$accountNumber, table = acc_bal$securitiesAccount.accountNumber)
  acc$amt2trade <- acc_bal[ilocs,'securitiesAccount.initialBalances.cashAvailableForTrading']
  # remove accounts with 0 amount to trade
  acc = subset(acc, acc$amt2trade >0)
  # try to open positions
  source("traderAPI.R")
  # send ORDERS for each account:
  # ***********************************************************************
  # send orders to first account if amount to trade is available
  if(acc$amt2trade[1] > sum(stks2trade$prc)){
    allOrds1 = do.call(c, lapply(as.list(stks2trade$symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[1], ticker = tic, side = "BUY",
                                 sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
  }else{
    # otherwise just fill 1 stock
    oneStk = stks2trade[which(acc$amt2trade[1] > stks2trade$prc)[1],]
    allOrds1 = do.call(c, lapply(as.list(oneStk$symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[1], ticker = tic, side = "BUY",
                                   sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
    
  }
  # ***********************************************************************
  # send orders to second account if amount to trade is available
  if(acc$amt2trade[2] > sum(stks2trade$prc)){
    allOrds2 = do.call(c, lapply(as.list(stks2trade$symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[2], ticker = tic, side = "BUY",
                                   sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
  }else{
    # otherwise just fill 1 stock
    oneStk = stks2trade[which(acc$amt2trade[2] > stks2trade$prc)[1],]
    allOrds2 = do.call(c, lapply(as.list(oneStk$symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[2], ticker = tic, side = "BUY",
                                   sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
  }
  # ************************************************************************************************************************************************************************
  # sleep for 2 seconds to get order history
  Sys.sleep(5)
  ordHist1 = cs_getOrders(accNum = acc$hashValue[1],maxResults = 10, fromEnteredTime = Sys.Date()-1,toEnteredTime =  Sys.Date()+1,status = NULL)
  ordHist2 = cs_getOrders(accNum = acc$hashValue[2],maxResults = 10, fromEnteredTime = Sys.Date()-1,toEnteredTime =  Sys.Date()+1,status = NULL)
  # combine order history
  allOrdHist = rbind.fill(ordHist1,ordHist2)
  # combine order ID's
  allOrds = c(allOrds1,allOrds2)
  # match up the orders ids to the ones in the order history
  allOrdHist = allOrdHist[match(allOrds, table = allOrdHist$orderId),]
  # subset where filled quantity is > 1
  allOrdHist = subset(allOrdHist, allOrdHist$filledQuantity > 0)
  # split by account
  acc1_close = allOrdHist[allOrdHist$accountNumber == acc$accountNumber[1],]
  acc2_close = allOrdHist[allOrdHist$accountNumber == acc$accountNumber[2],]
  # ************************************************************************************************************************************************************************
  pause2close = function(ttc, silent=FALSE){
    while(Sys.time() < ttc){
      ttt <- ttc - Sys.time()
      HMS <- attr(ttt,"units")
      tt <- as.numeric(ttt)
      if(HMS == "days")
      {
        if(!silent){cat("\n", sprintf("Current Time: %s | Days Remaining: %s ",paste(Sys.time()),round(as.numeric(ttc-Sys.time()),4)))}
        Sys.sleep(10)
      }
      if(HMS == "hours")
      {
        if(!silent){cat("\n", sprintf("Current Time: %s | Hours Remaining: %s ",paste(Sys.time()),round(as.numeric(ttc-Sys.time()),4)))}
        Sys.sleep(5)
      }
      if(HMS == "mins")
      {
        if(!silent){cat("\n", sprintf("Current Time: %s | Minutes Remaining: %s ",paste(Sys.time()),round(as.numeric(ttc-Sys.time()),4)))}
        Sys.sleep(1)
      }
      if(HMS == "secs")
      {
        if(!silent){cat("\nCurrent Time: ",paste(Sys.time()),"| Seconds Remaining: ",round(as.numeric(ttc-Sys.time()),4))}
        Sys.sleep(0.1)
      } 
      
    }
  }
  pause2close(ttc=ttc)
  source("traderAPI.R")
  # close order at the market price
  if(nrow(acc1_close)>0){
    sellOrds1 = do.call(c, lapply(as.list(acc1_close$orderLegCollection.instrument.symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[1], ticker = tic, side = "SELL",
                                   sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
  }
  if(nrow(acc2_close)>0){
    sellOrds2 = do.call(c, lapply(as.list(acc2_close$orderLegCollection.instrument.symbol), function(tic){
      ordNum = cs_placeSingleOrder(accNum = acc$hashValue[2], ticker = tic, side = "SELL",
                                   sess = "NORMAL", dur = "DAY", ordType = "MARKET", qty = 1, aType = 'EQUITY')    
    }))
  }
  # END OF ALGO
  cat("\n\n Algo Done!")
}else{
  cat("\nNot A Business Day!! - End-Of-Script!!!")
}