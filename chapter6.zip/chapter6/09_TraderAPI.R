require("httr");require("stringr");require("RCurl");require("lubridate");require("data.table");require("quantmod")
# file.edit("cs_authentication.Rmd")
pw = new.env()
assign("app_key","ADD_YOUR_APP_KEY",envir = pw)
assign("secret","ADD SECRET",envir = pw)
assign("acc_token",readRDS("cs_tokens.rds")$access_token,envir = pw)
redirect_url = 'https://127.0.0.1'
options(scipen = 999)
# acc <- cs_getAccNum()
# mainAcc <- acc$hashValue[str_detect(acc$accountNumber, pattern = "031")]
# ************************************************************************************************************************************************
#                                           Helper Functions
# ************************************************************************************************************************************************
# Underlying Symbol (6 characters including spaces) | Expiration (6 characters) | Call/Put (1 character) | Strike Price (5+3=8 characters) 
cs_optSym = function(under_sym, exp, type, strike){
  sym = gsub(" ", "%20", str_pad(under_sym, width=6, side = "right"))
  exp = format(as.Date(exp),"%y%m%d")
  strike = as.character(as.integer(strike*100))
  if(str_length(strike) == 7){strike = paste0(strike,"0")}
  if(str_length(strike) == 6){strike = paste0("0",strike,"0")}
  if(str_length(strike) == 5){strike = paste0("00",strike,"0")}
  if(str_length(strike) == 4){strike = paste0("000",strike,"0")}
  if(str_length(strike) == 3){strike = paste0("0000",strike,"0")}
  if(str_length(strike) == 2){strike = paste0("00000",strike,"0")}
  paste0(sym,exp,type,strike)
}
# renews Access Token if applicable
checkAccessToken = function(printMsg){
  # check if tokens are saved
  if(file.exists("cs_tokens.rds")){
    # read in token file if it exists
    tokens = readRDS("cs_tokens.rds")
    # check which ones need renewal
    getNewAccTkn = (as.POSIXct(tokens$access_token_exp,tz = Sys.timezone()) < Sys.time())
    getNewRefTkn = (as.POSIXct(tokens$refresh_token_exp,tz = Sys.timezone()) < Sys.time())
  }
  # if token file does not exist then notify
  if(!file.exists('cs_tokens.rds')){
    getNewAccTkn = NULL
    getNewRefTkn = NULL
  }
  # ******************************************************************************************************************
  #                     Renew only if getNewAccTkn = TRUE & getNewRefTkn = FALSE
  # ******************************************************************************************************************
  if(getNewAccTkn & !getNewRefTkn){  
    # authentication url
    URL = 'https://api.schwabapi.com/v1/oauth/token' 
    # add payload
    payload = list('grant_type'='refresh_token','refresh_token'= tokens$refresh_token)
    # maket post request
    pg <- httr::POST(url=URL,
                     body = payload,
                     httr::add_headers(`Authorization` = paste0("Basic ",base64Encode(paste0(pw$app_key,":",pw$secret))[1]),
                                       `Content-Type` = 'application/x-www-form-urlencoded'),
                     encode="form" 
    )
    # get time - to know when to renew
    got_time = as.POSIXct(pg[["date"]],tz = Sys.timezone())
    if(httr::status_code(pg)== 200){
      resp <- httr::content(pg)
      # A Trader API access token is valid for 30 minutes. A Trader API refresh token is valid for 7 days.
      resp <- c(resp, 
                list(access_token_exp = got_time + minutes(30),
                     refresh_token_exp = tokens$refresh_token_exp))
      # save as binary file
      saveRDS(resp,"cs_tokens.rds")
      assign("acc_token",resp$access_token,envir = pw)
      #assign("ref_token",resp$refresh_token,envir = pw)
      if(printMsg){cat("\n",sprintf("%-30s : %-20s", "Renewed 30-minute Access Token", "File Saved"))}
    }else{
      cat("\n",sprintf("%-30s : %-20s", "Unable To Get New Access Token ", httr::content(pg)$error_description))
    }
  }
  # ******************************************************************************************************************
  #                     If Both Are Null, We don't have a file & need to generate one (manually)
  # ******************************************************************************************************************
  if(is.null(getNewAccTkn) & is.null(getNewRefTkn)){if(printMsg){cat("\n",sprintf("%-30s : %-20s", "Error", "Token File Does Not Exist"))}}
  # ******************************************************************************************************************
  #                     If Refresh Token is Expired, Notify
  # ******************************************************************************************************************
  if(getNewRefTkn){if(printMsg){cat("\n",sprintf("%-30s : %-20s", "7-Day Refresh Token Expired", "Please Renew"))}}
  # ******************************************************************************************************************
  #                     If Refresh Token & Access Token not expired, notify
  # ******************************************************************************************************************
  if(!getNewRefTkn & !getNewAccTkn){if(printMsg){cat("\n",sprintf("%-30s : %-20s", "Access/Refresh Token Valid", "No Action Required"))}}
}

# get quotes from CS. You can request multiple symbols separated by a comma
#'@param sym = Comma separated list of symbol(s) to look up a quote
#'@param fields = `quote`,`fundamental`, `all` 
#'@param indicative = `true`or `false`:If ETF symbol ABC and indicative=true API will return quotes for ABC and its corresponding indicative quote for $ABC.IV
# ************************************************************************************************************************************************
#                                           Get Quote 
# ************************************************************************************************************************************************
cs_getQuote = function(sym, fields, indicative){
  # build url
  URL = paste0('https://api.schwabapi.com/marketdata/v1/quotes?symbols=',sym,'&fields=',fields,'%2Creference&indicative=',tolower(indicative))
  # get request
  checkAccessToken(printMsg = FALSE)
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  # if status code is 200 then extract data
  if(pg$status_code == 200){
    # extract page contents
    tbl <- httr::content(pg)
    df = lapply(as.list(1:length(tbl)),function(i){
      # combine all data
      data.frame(t(as.data.frame(unlist(tbl[[i]]))), row.names = NULL)
    })
    # return all data as a data frame
    df = as.data.frame(rbindlist(df, use.names = T, fill = T))
    
  }else{
    cat("\nFailed To Get Quote, Status Code: ",pg$status_code)
  }
  df
}
# ************************************************************************************************************************************************
#                                           get option Chains: file.edit("cs_OpChains.Rmd")
# ************************************************************************************************************************************************
#'@param                 symbol = underlying symbol
#'@param           contractType = contract type: `CALL`, `PUT`, or `ALL`
#'@param            strikeCount = The Number of strikes to return above or below the at-the-money price
#'@param includeUnderlyingQuote = should the underlying quote be included? `TRUE` or `FALSE`
#'@param               strategy = OptionChain strat: `SINGLE`, `ANALYTICAL`, `COVERED`, `VERTICAL`, `CALENDAR`, `STRANGLE`, `STRADDLE`, `DIAGONAL`, 
#'                                `BUTTERFLY`,`CONDOR`, `COLLAR`, `ROLL`
#'@param               interval = Strike interval for spread strategy chains (see strategy param)
#'@param                 strike = Strike Price
#'@param                  range = Range(`ITM`/`NTM`/`OTM` etc.)
#'@param               fromDate = From date(pattern: yyyy-MM-dd)
#'@param                 toDate = To date (pattern: yyyy-MM-dd)
#'@param             volatility = Volatility to use in calculations. Applies only to ANALYTICAL strategy chains (see strategy param)
#'@param        underlyingPrice = Underlying price to use in calculations. Applies only to ANALYTICAL strategy chains (see strategy param)
#'@param           interestRate = Interest rate to use in calculations. Applies only to ANALYTICAL strategy chains (see strategy param)
#'@param       daysToExpiration = Days to expiration to use in calculations. Applies only to ANALYTICAL strategy chains (see strategy param)
#'@param               expMonth = expiration month: `JAN`,`FEB`,`MAR`...etc or `ALL`
#'@param             optionType = Option Type
#'@param            entitlement = Applicable only if its retail token, entitlement of client PP-PayingPro, NP-NonPro and PN-NonPayingPro
cs_getOpChains = function(symbol,contractType=NULL,strikeCount=NULL,includeUnderlyingQuote=NULL,strategy=NULL,interval=NULL,strike=NULL, 
                          range=NULL,fromDate=NULL,toDate=NULL, volatility=NULL, underlyingPrice=NULL, interestRate=NULL, daysToExpiration=NULL,
                          expMonth=NULL, optionType=NULL, entitlement=NULL){
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/chains",
               ifelse(!is.null(symbol),paste0("?symbol=",symbol), ""),
               ifelse(!is.null(contractType),paste0("&contractType=",contractType), ""),
               ifelse(!is.null(strikeCount),paste0("&strikeCount=", strikeCount) , ""),
               ifelse(!is.null(includeUnderlyingQuote),paste0("&includeUnderlyingQuote=",includeUnderlyingQuote), ""),
               ifelse(!is.null(strategy),paste0("&strategy=", strategy) , ""),
               ifelse(!is.null(interval),paste0("&interval=",interval), ""),
               ifelse(!is.null(strike),paste0("&strike=", strike) , ""),
               ifelse(!is.null(range),paste0("&range=",range), ""),
               ifelse(!is.null(fromDate),paste0("&fromDate=", fromDate) , ""),
               ifelse(!is.null(toDate),paste0("&toDate=",toDate), ""),
               ifelse(!is.null(volatility),paste0("&volatility=", volatility) , ""),
               ifelse(!is.null(underlyingPrice),paste0("&underlyingPrice=",underlyingPrice), ""),
               ifelse(!is.null(interestRate) ,paste0("&interestRate=", interestRate) , ""),
               ifelse(!is.null(daysToExpiration),paste0("&daysToExpiration=",daysToExpiration), ""),
               ifelse(!is.null(expMonth) ,paste0("&expMonth=", expMonth) , ""),
               ifelse(!is.null(optionType),paste0("&optionType=",optionType), ""),
               ifelse(!is.null(entitlement) ,paste0("&entitlement=", entitlement) , "")
  )
  
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl <- httr::content(pg)
    if(includeUnderlyingQuote){
      # add underlying symbol data
      uData <- as.data.frame(tbl[["underlying"]])
      # add "u" in front of column names to distinguish Underlying data
      names(uData) <- paste0("u",names(uData))
    }
    # ****************************************************************************************
    #                                 ALL CALLS
    # ****************************************************************************************
    if(strategy == 'SINGLE' | strategy =="ANALYTICAL"){
      # if user selects CALL only or ALL
      if(contractType == "CALL" | contractType == "ALL"){
        # if these are single options (i.e. no strategy)
        ops_calls = lapply(as.list(1:length(tbl$callExpDateMap)),function(exp){
          # subset to expiration
          this_exp <- tbl$callExpDateMap[[exp]]
          # isolate strikes
          ALL = lapply(as.list(1:length(this_exp)), function(strike){
            # extract each strike from expiration level
            this_op <- this_exp[[strike]]
            # return as data frame
            as.data.frame(rbind(unlist(this_op)))
          })
          # combine all data
          df = as.data.frame(do.call(rbind,ALL))
        })
        # return all data as a data frame
        ops_calls = as.data.frame(rbindlist(ops_calls, use.names = T, fill = T))
      }
      # ****************************************************************************************
      #                                 ALL PUTS
      # ****************************************************************************************
      # if user selects PUT only or ALL
      if(contractType =="PUT" | contractType == "ALL"){
        ops_puts = lapply(as.list(1:length(tbl$putExpDateMap)),function(exp){
          # subset to expiration
          this_exp <- tbl$putExpDateMap[[exp]]
          # isolate strikes
          ALL = lapply(as.list(1:length(this_exp)), function(strike){
            # extract each strike from expiration level
            this_op <- this_exp[[strike]]
            # return as data frame
            as.data.frame(rbind(unlist(this_op)))
          })
          # combine all data
          df = as.data.frame(do.call(rbind,ALL))
        })
        # return all data as a data frame
        ops_puts = as.data.frame(rbindlist(ops_puts, use.names = T, fill = T))
      }
      # ****************************************************************************************
      #                                 COMBINE BOTH
      # ****************************************************************************************
      if(contractType == "ALL"){
        # row bind calls and puts
        all_ops = rbind(ops_calls, ops_puts)
        # add underlying quote if TRUE
        if(includeUnderlyingQuote){
          # final data frame, merge with underlying data
          final_ops <- as.data.frame(cbind(all_ops,uData))
        }else{
          final_ops <- as.data.frame(all_ops)
        }
      }
      if(contractType == "CALL"){
        # row bind calls and puts
        all_ops = ops_calls
        # add underlying quote if TRUE
        if(includeUnderlyingQuote){
          # final data frame, merge with underlying data
          final_ops <- as.data.frame(cbind(all_ops,uData))
        }else{
          final_ops <- as.data.frame(all_ops)
        }
      }
      if(contractType == "PUT"){
        # row bind calls and puts
        all_ops = ops_puts
        # add underlying quote if TRUE
        if(includeUnderlyingQuote){
          # final data frame, merge with underlying data
          final_ops <- as.data.frame(cbind(all_ops,uData))
        }else{
          final_ops <- as.data.frame(all_ops)
        }
      }
      # **********************************************************************************************************************************************************
      # all columns that should be numeric
      nCols = c("bid","ask","last","mark","bidSize","askSize","lastSize","highPrice","lowPrice","openPrice","closePrice","totalVolume","tradeTimeInLong",
                "quoteTimeInLong","netChange","volatility","delta","gamma","theta","vega","rho","openInterest","timeValue","theoreticalOptionValue",
                "theoreticalVolatility","optionDeliverablesList.deliverableUnits","strikePrice","daysToExpiration","lastTradingDay","multiplier",
                "percentChange","markChange","markPercentChange","intrinsicValue","extrinsicValue","high52Week","low52Week")
      # column number in final_ops
      ilocs = which(names(final_ops) %in% nCols)
      # change column classes fast
      setDT(final_ops)[, c(ilocs) := lapply (.SD, function(x) round(as.numeric(x),4)), .SDcols=c(ilocs)]
      # fix Dates
      final_ops$expirationDate <- as.character(as.Date(final_ops$expirationDate, format="%Y-%m-%dT%H:%M:%OS"))
      final_ops$tradeTimeInLong<- as.character(as.POSIXct(final_ops$tradeTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$quoteTimeInLong<- as.character(as.POSIXct(final_ops$quoteTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$lastTradingDay <- as.character(as.POSIXct(final_ops$lastTradingDay/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$uquoteTime     <- as.character(as.POSIXct(final_ops$uquoteTime/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$utradeTime     <- as.character(as.POSIXct(final_ops$utradeTime/1000, tz = "America/New_York",origin = "1970-01-01"))
      # **********************************************************************************************************************************************************
      # **********************************************************************************************************************************************************
    }else{
      
      # if this is a strategy:
      all_ops = lapply(as.list(1:length(tbl[["monthlyStrategyList"]])), function(i){
        # subset each strategy's legs
        tmp_ops = tbl[["monthlyStrategyList"]][[i]]
        # extract metadata
        META = data.frame(expMo = tbl[["monthlyStrategyList"]][[i]][["month"]],
                          expYr = tbl[["monthlyStrategyList"]][[i]][["year"]],
                          expDay= tbl[["monthlyStrategyList"]][[i]][["day"]],
                          dte   = tbl[["monthlyStrategyList"]][[i]][["daysToExp"]]
        )
        # dig through each option list
        ops = lapply(as.list(1:length(tbl[["monthlyStrategyList"]][[i]][["optionStrategyList"]])), function(k){
          # unlist and combine
          as.data.frame(t(unlist(tbl[["monthlyStrategyList"]][[i]][["optionStrategyList"]][[k]])))
        })
        # combine all ops
        ops = as.data.frame(rbindlist(ops, use.names = T,fill = T))
        # add META data
        ops = cbind(ops,META)
        # return ops data frame
        ops
      })
      # combine all expirations
      final_ops = as.data.frame(rbindlist(all_ops,use.names = T,fill = T))
      # ****************************************************************************************  
      # ****************************************************************************************  
      # convert to numeric columns
      nCols = c("primaryLeg.bid", "primaryLeg.ask", "primaryLeg.volume", "primaryLeg.strikePrice","primaryLeg.lastPrice", "primaryLeg.mark", "primaryLeg.bidSize", 
                "primaryLeg.askSize", "primaryLeg.lastSize", "primaryLeg.highPrice", "primaryLeg.lowPrice", "primaryLeg.high52Week", "primaryLeg.low52Week", 
                "primaryLeg.openPrice", "primaryLeg.closePrice", "primaryLeg.openInterest","primaryLeg.netChange", "primaryLeg.volatility", "primaryLeg.delta", 
                "primaryLeg.gamma", "primaryLeg.theta", "primaryLeg.vega", "primaryLeg.rho", "primaryLeg.tradeTimeInLong", "primaryLeg.quoteTimeInLong",
                "primaryLeg.percentChange", "primaryLeg.intrinsicValue", "primaryLeg.extrinsicValue", "primaryLeg.totalVolume", "secondaryLeg.bid", "secondaryLeg.ask", 
                "secondaryLeg.volume","secondaryLeg.strikePrice", "secondaryLeg.lastPrice", "secondaryLeg.mark","secondaryLeg.bidSize", "secondaryLeg.askSize", 
                "secondaryLeg.lastSize", "secondaryLeg.highPrice", "secondaryLeg.lowPrice", "secondaryLeg.high52Week", "secondaryLeg.low52Week", "secondaryLeg.openPrice", 
                "secondaryLeg.closePrice", "secondaryLeg.openInterest", "secondaryLeg.netChange", "secondaryLeg.volatility", "secondaryLeg.delta", "secondaryLeg.gamma", 
                "secondaryLeg.theta", "secondaryLeg.vega", "secondaryLeg.rho", "secondaryLeg.tradeTimeInLong", "secondaryLeg.quoteTimeInLong", "secondaryLeg.percentChange", 
                "secondaryLeg.intrinsicValue", "secondaryLeg.extrinsicValue", "secondaryLeg.totalVolume", "strategyBid", "strategyAsk", "strategyMark", "strategyDelta", 
                "strategyGamma", "strategyTheta", "strategyVega", "strategyRho")
      # column number in final_ops
      ilocs = which(names(final_ops) %in% nCols)
      # change column classes fast
      setDT(final_ops)[, c(ilocs) := lapply (.SD, function(x) round(as.numeric(x),4)), .SDcols=c(ilocs)]
      # fix times
      final_ops$primaryLeg.tradeTimeInLong<- as.character(as.POSIXct(final_ops$primaryLeg.tradeTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$primaryLeg.quoteTimeInLong<- as.character(as.POSIXct(final_ops$primaryLeg.quoteTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$secondaryLeg.tradeTimeInLong <- as.character(as.POSIXct(final_ops$secondaryLeg.tradeTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      final_ops$secondaryLeg.quoteTimeInLong     <- as.character(as.POSIXct(final_ops$secondaryLeg.quoteTimeInLong/1000, tz = "America/New_York",origin = "1970-01-01"))
      # include underlying data if TRUE
      if(includeUnderlyingQuote){
        final_ops  = cbind(final_ops, uData)
        final_ops$uquoteTime <- as.character(as.POSIXct(final_ops$uquoteTime/1000, tz = "America/New_York",origin = "1970-01-01"))
        final_ops$utradeTime <- as.character(as.POSIXct(final_ops$utradeTime/1000, tz = "America/New_York",origin = "1970-01-01"))
      }
      # convert to data frame
      final_ops <- as.data.frame(final_ops)
    }
    # add get date
    final_ops$date <- as.character(Sys.Date())
    # remove any NA columns
    final_ops <- as.data.frame(final_ops)
    final_ops <- final_ops[,colSums(is.na(final_ops)) != nrow(final_ops)]
    # return table 
    final_ops
    
  }else{cat("\nFailed To Get Option Chains, Status Code: ",pg$status_code)}
  final_ops
}
# ************************************************************************************************************************************************
#                                           get historical bars : file.edit("cs_priceHist.Rmd")
# ************************************************************************************************************************************************
#'@param symbol     = The Equity symbol used to look up price history
#'@param periodType = The chart period being requested. `day`, `month`, `year`, `ytd`
#'@param period     = The number of chart period types. Valid Values are:
#'          [`day`] = `1`, `2`, `3`, `4`, `5`, `10` (default: 10)
#'        [`month`] = `1`, `2`, `3`, `6` (default: 1)
#'         [`year`] = `1`, `2`, `3`, `5`, `10`, `15`, `20` (default: 1)
#'          [`ytd`] = `1` (default: 1)
#'@param frequencyType = The time frequencyType. Valid Values:
#'          [`day`] = `minute` (default: minute)
#'        [`month`] = `daily`, `weekly` (default: weekly)
#'         [`year`] = `daily`, `weekly`, `monthly` (default: monthly)
#'          [`ytd`] = `daily`, `weekly`, `monthly` (default: weekly)
#'@param freq       = The time frequency duration
#'       [`minute`] = `1`, `5`, `10`, `15`, `30`
#'        [`daily`] = `1`
#'       [`weekly`] = `1`
#'      [`monthly`] = `1`
#'@param startDate = start date,Time in millisecs since the UNIX epoch.If not specified startDate will be (endDate-period) excluding weekends and holidays.
#'@param endDate   = end date,Time in millisecs since the UNIX epoch.If not specified the endDate will default to the market-close of prev. business day.
#'@param needExtendedHoursData = Need extended hours data `TRUE` or `FALSE`
#'@param needPreviousClose     = Need previous close price/date `TRUE` or `FALSE`
#'@param asXTS     = should an XTS object be returned: `TRUE` or `FALSE`

cs_getHistBars = function(symbol,periodType,period,frequencyType,freq,startDate=NULL,endDate=NULL,needExtendedHoursData=NULL,needPreviousClose=NULL,asXTS=FALSE){
  # convert to numeric start date
  if(!is.null(startDate)){
    startDate = as.character(as.numeric(as.POSIXct(paste0(startDate," 09:30:00"), origin="1970-01-01", tz="America/New_York"))*1000)
  }
  if(!is.null(endDate)){
    endDate = as.character(as.numeric(as.POSIXct(paste0(endDate," 09:30:00"), origin="1970-01-01", tz="America/New_York"))*1000)
  }
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/pricehistory",
               ifelse(!is.null(symbol),paste0("?symbol=",symbol), ""),
               ifelse(!is.null(periodType),paste0("&periodType=",periodType), ""),
               ifelse(!is.null(period),paste0("&period=",period), ""),
               ifelse(!is.null(frequencyType),paste0("&frequencyType=", frequencyType) , ""),
               ifelse(!is.null(freq),paste0("&frequency=",freq), ""),
               ifelse(!is.null(startDate),paste0("&startDate=", startDate) , ""),
               ifelse(!is.null(endDate),paste0("&endDate=",endDate), ""),
               ifelse(!is.null(needExtendedHoursData),paste0("&needExtendedHoursData=", needExtendedHoursData) , ""),
               ifelse(!is.null(needPreviousClose),paste0("&needPreviousClose=",needPreviousClose), "")
  )
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract content 
    tbl = httr::content(pg)
    if(!tbl[["empty"]]){
      # extract candles
      df <- as.data.frame(rbindlist(tbl[["candles"]],use.names = T,fill = T))
      # convert to XTS
      if(asXTS){
        # if minute data order by as.POSIXct(), otherwise by as.Date()
        if(frequencyType == 'minute'){
          BARS = xts(df[,c("open","high","low","close","volume")], 
                     order.by = as.POSIXct(as.numeric(df$datetime)/1000, origin = "1970-01-01", tz = "America/New_York"))
          # add previous close if requested
          if(!is.null(needPreviousClose)){
            prevClose = xts(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA))),
                            order.by = as.POSIXct(tbl[["previousCloseDate"]]/1000, origin="1970-01-01", tz = "America/New_York"))
            colnames(prevClose) = names(BARS)
            BARS = rbind(prevClose, BARS)
          }
          
        }else{
          BARS = xts(df[,c("open","high","low","close","volume")], 
                     order.by = as.Date(as.POSIXct(as.numeric(df$datetime)/1000, origin = "1970-01-01", tz = "America/New_York")))
          # add previous close if requested
          if(!is.null(needPreviousClose)){
            prevClose = xts(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA))),
                            order.by = as.Date(as.POSIXct(tbl[["previousCloseDate"]]/1000, origin="1970-01-01", tz = "America/New_York")))
            colnames(prevClose) = names(BARS)
            BARS = rbind(prevClose, BARS)
          }
        }
        # format column names
        colnames(BARS) = paste0(symbol,c(".Open",".High",".Low",".Close",".Volume"))
      }else{
        # assign BARS
        BARS <- df
        # add previous BAR if needed
        if(!is.null(needPreviousClose)){
          prevClose = data.frame(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA,tbl[["previousCloseDate"]]))), row.names = NULL)
          colnames(prevClose) = names(BARS)
          BARS = rbind(prevClose, BARS)
        }
        # add symbol as a column
        BARS$symbol <- symbol
      }
    }else{
      cat("\nGET Request Successful But No Bars to Return!")
      BARS = NULL
    }
    
  }else{
    cat("\nError: Status Code: ", pg$status_code)
  }
  
  # return BARS
  BARS
}
cs_getFutHistBars = function(symbol,periodType,period,frequencyType,freq,startDate=NULL,endDate=NULL,needExtendedHoursData=NULL,needPreviousClose=NULL,asXTS=FALSE){
  # convert to numeric start date
  if(!is.null(startDate)){
    startDate = as.character(as.numeric(as.POSIXct(paste0(startDate," 00:00:01"), origin="1970-01-01", tz="America/New_York"))*1000)
  }
  if(!is.null(endDate)){
    endDate = as.character(as.numeric(as.POSIXct(paste0(endDate," 23:59:59"), origin="1970-01-01", tz="America/New_York"))*1000)
  }
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/pricehistory",
               ifelse(!is.null(symbol),paste0("?symbol=",symbol), ""),
               ifelse(!is.null(periodType),paste0("&periodType=",periodType), ""),
               ifelse(!is.null(period),paste0("&period=",period), ""),
               ifelse(!is.null(frequencyType),paste0("&frequencyType=", frequencyType) , ""),
               ifelse(!is.null(freq),paste0("&frequency=",freq), ""),
               ifelse(!is.null(startDate),paste0("&startDate=", startDate) , ""),
               ifelse(!is.null(endDate),paste0("&endDate=",endDate), ""),
               ifelse(!is.null(needExtendedHoursData),paste0("&needExtendedHoursData=", needExtendedHoursData) , ""),
               ifelse(!is.null(needPreviousClose),paste0("&needPreviousClose=",needPreviousClose), "")
  )
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract content 
    tbl = httr::content(pg)
    if(!tbl[["empty"]]){
      # extract candles
      df <- as.data.frame(rbindlist(tbl[["candles"]],use.names = T,fill = T))
      # convert to XTS
      if(asXTS){
        # if minute data order by as.POSIXct(), otherwise by as.Date()
        if(frequencyType == 'minute'){
          BARS = xts(df[,c("open","high","low","close","volume")], 
                     order.by = as.POSIXct(as.numeric(df$datetime)/1000, origin = "1970-01-01", tz = "America/New_York"))
          # add previous close if requested
          if(!is.null(needPreviousClose)){
            prevClose = xts(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA))),
                            order.by = as.POSIXct(tbl[["previousCloseDate"]]/1000, origin="1970-01-01", tz = "America/New_York"))
            colnames(prevClose) = names(BARS)
            BARS = rbind(prevClose, BARS)
          }
          
        }else{
          BARS = xts(df[,c("open","high","low","close","volume")], 
                     order.by = as.Date(as.POSIXct(as.numeric(df$datetime)/1000, origin = "1970-01-01", tz = "America/New_York")))
          # add previous close if requested
          if(!is.null(needPreviousClose)){
            prevClose = xts(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA))),
                            order.by = as.Date(as.POSIXct(tbl[["previousCloseDate"]]/1000, origin="1970-01-01", tz = "America/New_York")))
            colnames(prevClose) = names(BARS)
            BARS = rbind(prevClose, BARS)
          }
        }
        # format column names
        colnames(BARS) = paste0(symbol,c(".Open",".High",".Low",".Close",".Volume"))
      }else{
        # assign BARS
        BARS <- df
        # add previous BAR if needed
        if(!is.null(needPreviousClose)){
          prevClose = data.frame(t(data.frame(c(NA,NA,NA,tbl[["previousClose"]],NA,tbl[["previousCloseDate"]]))), row.names = NULL)
          colnames(prevClose) = names(BARS)
          BARS = rbind(prevClose, BARS)
        }
        # add symbol as a column
        BARS$symbol <- symbol
      }
    }else{
      cat("\nGET Request Successful But No Bars to Return!")
      BARS = NULL
    }
    
  }else{
    cat("\nError: Status Code: ", pg$status_code)
  }
  
  # return BARS
  BARS
}
# ************************************************************************************************************************************************
#                                           misc data functions : file.edit('/Volumes/6TB/R/cs_miscMktData.Rmd')
# ************************************************************************************************************************************************
#'@param symbol_id = Index Symbol (`$DJI`,`$COMPX`,`$SPX`,`NYSE`,`NASDAQ`,`OTCBB`,`INDEX_ALL`,`EQUITY_ALL`,`OPTION_ALL`,`OPTION_PUT`,`OPTION_CALL`)
#'@param      sort = Sort by a particular attribute (`VOLUME`, `TRADES`, `PERCENT_CHANGE_UP`, `PERCENT_CHANGE_DOWN`)
#'@param      freq = To return movers with the specified directions of up or down (`0`, `1`, `5`, `10`, `30`, `60`)
cs_getMktMovers = function(symbol_id, sort, freq){
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/movers/",
               ifelse(!is.null(symbol_id),paste0(gsub("\\$","%24",symbol_id)), ""),
               ifelse(!is.null(sort),paste0("?sort=",sort), ""),
               ifelse(!is.null(freq),paste0("&frequency=",freq), "")
  )
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl = httr::content(pg)
    # return as data frame 
    df <- as.data.frame(rbindlist(tbl[["screeners"]],use.names = T,fill = T))
  }else{
    # return error
    ERROR <- content(pg)
    ERROR <- as.data.frame(rbindlist(ERROR$errors,use.names = T,fill = T))
    ERROR <- ERROR[,c('status','title','detail','source')]
    cat("\nError!")
    print(ERROR)
    # will assign df as NULL
    df = NULL
  }
  # return df
  df
}
# get option expiration dates
#'@param symbol = Enter one symbol (ex. `TSLA`)
cs_getExpChains = function(symbol){
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/expirationchain",
               ifelse(!is.null(symbol),paste0("?symbol=",symbol), "")
  )
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl = httr::content(pg)
    if(nrow(rbindlist(tbl[["expirationList"]]))>0){
      # return as data frame 
      df <- as.data.frame(rbindlist(tbl[["expirationList"]],use.names = T,fill = T))
    }else{
      # no rows to return
      cat("\nError! No Rows to return\n")
      df=NULL
    }
  }
  # return df
  df
}
# get market hours
#'@param      date = Valid date range is from currentdate to 1 year from today. It will default to current day if not entered. Date format: `YYYY-MM-DD`
cs_getMktHrs = function(date){
  # build URL
  #'@param market_id = market id : `equity`, `option`, `bond`, `future`, `forex`
  URL = paste0('https://api.schwabapi.com/marketdata/v1/markets?markets=equity&markets=option&markets=bond&markets=future&markets=forex&date=',date)
  
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl = httr::content(pg)
    # nested lists, combine all data
    df = lapply(as.list(1:length(tbl)), function(i){
      # sub each major list
      tmp = tbl[[i]]
      # get all contents within major list
      ALL = lapply(as.list(1:length(tmp)), function(k){
        # combine data
        all = as.data.frame(t(unlist(tmp[[k]])))
      })
      # return as data frame
      as.data.frame(rbindlist(ALL,use.names = T,fill = T))
    })
    # return as data frame 
    df = as.data.frame(rbindlist(df, use.names = T,fill = T))
    # format all timestamps
    df[,c(6:ncol(df))] <- sapply(as.list(6:ncol(df)), function(i){as.character(as.POSIXct(df[,i],tz ="America/New_York", format="%Y-%m-%dT%H:%M:%OS"))})
    
  }else{
    # return error
    ERROR <- content(pg)
    ERROR <- as.data.frame(rbindlist(ERROR$errors,use.names = T,fill = T))
    ERROR <- ERROR[,c('status','title','detail','source')]
    cat("\nError!\n")
    print(ERROR)
    # will assign df as NULL
    df = NULL
  }
  # return df
  df
}
#'@param     symbol = symbol of a security (ex. `TSLA`)
#'@param projection = search by : `symbol-search`, `symbol-regex`, `desc-search`, `desc-regex`, `search`, `fundamental`
# get instruments
cs_getInstruments = function(symbol, projection){
  # build URL
  URL = paste0("https://api.schwabapi.com/marketdata/v1/instruments?symbol=",symbol,"&projection=",projection)
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl = httr::content(pg)
    # rbind all results if not fundamental
    if(length(tbl) != 0){
      if(projection != "fundamental"){
        df = as.data.frame(rbindlist(tbl[["instruments"]],use.names = T,fill = T))
      }
      # convert columns to numeric if fundamental data
      if(projection == "fundamental"){
        # combine all data
        df <- as.data.frame(t(unlist(tbl[["instruments"]])))
        nCols = c( "fundamental.high52", "fundamental.low52", 
                   "fundamental.dividendAmount", "fundamental.dividendYield", "fundamental.peRatio", 
                   "fundamental.pegRatio", "fundamental.pbRatio", "fundamental.prRatio", 
                   "fundamental.pcfRatio", "fundamental.grossMarginTTM", "fundamental.grossMarginMRQ", 
                   "fundamental.netProfitMarginTTM", "fundamental.netProfitMarginMRQ", 
                   "fundamental.operatingMarginTTM", "fundamental.operatingMarginMRQ", 
                   "fundamental.returnOnEquity", "fundamental.returnOnAssets", "fundamental.returnOnInvestment", 
                   "fundamental.quickRatio", "fundamental.currentRatio", "fundamental.interestCoverage", 
                   "fundamental.totalDebtToCapital", "fundamental.ltDebtToEquity", 
                   "fundamental.totalDebtToEquity", "fundamental.epsTTM", "fundamental.epsChangePercentTTM", 
                   "fundamental.epsChangeYear", "fundamental.epsChange", "fundamental.revChangeYear", 
                   "fundamental.revChangeTTM", "fundamental.revChangeIn", "fundamental.sharesOutstanding", 
                   "fundamental.marketCapFloat", "fundamental.marketCap", "fundamental.bookValuePerShare", 
                   "fundamental.shortIntToFloat", "fundamental.shortIntDayToCover", 
                   "fundamental.divGrowthRate3Year", "fundamental.dividendPayAmount", 
                   "fundamental.beta", "fundamental.vol1DayAvg", "fundamental.vol10DayAvg", 
                   "fundamental.vol3MonthAvg", "fundamental.avg10DaysVolume", "fundamental.avg1DayVolume", 
                   "fundamental.avg3MonthVolume", "fundamental.dividendFreq", "fundamental.eps", 
                   "fundamental.dtnVolume", "fundamental.fundLeverageFactor")
        # column number in final_ops
        ilocs = which(names(df) %in% nCols)
        # change column classes fast
        setDT(df)[, c(ilocs) := lapply (.SD, function(x) round(as.numeric(x),4)), .SDcols=c(ilocs)]
      }
    }else{
      cat("\nNothing Returned\n")
    }
  }else{
    # return error
    ERROR <- content(pg)
    ERROR <- as.data.frame(rbindlist(ERROR$errors,use.names = T,fill = T))
    ERROR <- ERROR[,c('status','title','detail','source')]
    cat("\nError!")
    print(ERROR)
    # will assign df as NULL
    df = NULL
  }
  # return df
  df
}
# ************************************************************************************************************************************************
#                                           getAccount functions : file.edit("cs_accounts.Rmd")
# ************************************************************************************************************************************************
# no fields - must have their accessToken assigned to envir `pw`
cs_getAccNum = function(){
  # URL
  URL = paste0("https://api.schwabapi.com/trader/v1/accounts/accountNumbers")
  # check AccessToken
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  # if page status code is 200 then retrieve page contents
  if(httr::status_code(pg) == 200){
    # account values
    #acc = as.data.frame(httr::content(pg))
    accs = httr::content(pg)
    acc = do.call(rbind,lapply(as.list(1:length(accs)) ,function(i) as.data.frame(accs[[i]])))
  }else{
    # return error
    ERROR <- content(pg)
    ERROR <- as.data.frame(rbindlist(ERROR$errors,use.names = T,fill = T))
    ERROR <- ERROR[,c('status','title','detail')]
    cat("\nError!")
    print(ERROR)
    # will assign df as NULL
    acc = NULL
  }
  # return account info
  acc
}
# no fields - must have their accessToken assigned to envir `pw`
cs_getAccPos = function(fields){
  # URL
  URL = paste0("https://api.schwabapi.com/trader/v1/accounts?fields=",fields)
  # check AccessToken
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  # if page status code is 200 then retrieve page contents
  if(httr::status_code(pg) == 200){
    # account values
    tbl = httr::content(pg)
    # in case user has more than one account it will combine account info
    acc = as.data.frame(rbindlist(lapply(as.list(1:length(tbl)), function(i){
      acc = as.data.frame(tbl[[i]])  
    }),use.names = T,fill = T))
    
  }else{
    # return error
    ERROR <- content(pg)
    ERROR <- as.data.frame(rbindlist(ERROR$errors,use.names = T,fill = T))
    ERROR <- ERROR[,c('status','title','detail')]
    cat("\nError!")
    print(ERROR)
    # will assign df as NULL
    acc = NULL
  }
  # return account info
  acc
}
#'@param accountNumber = The encrypted ID of the account
#'@param        fields = This allows one to determine which fields they want returned. Possible value in this String can be: `positions`
# no fields - must have their accessToken assigned to envir `pw`
cs_getSpecAccPos = function(accountNumber,fields){
  # URL
  URL = paste0("https://api.schwabapi.com/trader/v1/accounts/",accountNumber,"?fields=",fields)
  # check AccessToken
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  # if page status code is 200 then retrieve page contents
  if(httr::status_code(pg) == 200){
    # account values
    tbl = httr::content(pg)
    # in case user has more than one account it will combine account info
    acc = as.data.frame(rbindlist(lapply(as.list(1:length(tbl)), function(i){
      acc = as.data.frame(tbl[[i]])  
    }),use.names = T,fill = T))
    
  }else{
    # return error
    ERROR <- content(pg)
    cat("\n",ERROR$message,"\n")
    # will assign df as NULL
    acc = NULL
  }
  # return account info
  acc
}
#'@param accountNumber = The encrypted ID of the account
#'@param     startDate = Specifies that no transactions entered before this time should be returned. Valid ISO-8601 formats are :
#'                       yyyy-MM-dd'T'HH:mm:ss.SSSZ Date must be within 60 days from today's date. 'endDate' must also be set.
#'@param       endDate = Specifies that no transactions entered after this time should be returned. Valid ISO-8601 formats are :
#'                       # yyyy-MM-dd'T'HH:mm:ss.SSSZ. 'startDate' must also be set.
#'@param        symbol = It filters all the transaction activities based on the symbol specified. #'
#'                       # NOTE: If there is any special character in the symbol, please send th encoded value.
#'@param         types = Specifies that only transactions of this status should be returned.
#'                      Available: `TRADE`, `RECEIVE_AND_DELIVER`, `DIVIDEND_OR_INTEREST`, `ACH_RECEIPT`, `ACH_DISBURSEMENT`, `CASH_RECEIPT`, `CASH_DISBURSEMENT`, 
#'                               # `ELECTRONIC_FUND`, `WIRE_OUT`, `WIRE_IN`, `JOURNAL`, `MEMORANDUM`, `MARGIN_CALL`, `MONEY_MARKET`, `SMA_ADJUSTMENT`
# startDate = "2023-01-04";endDate="2023-02-27"
cs_getTrans = function(accNumber, startDate, endDate, symbol=NULL, types=NULL){
  # convert start/end dates to ISO-8601 format  + URL
  URL = paste0("https://api.schwabapi.com/trader/v1/accounts/",accNumber,
               "/transactions?startDate=",
               strftime(as.POSIXct(paste0(as.Date(startDate)," 00:01:00"), "UTC"), "%Y-%m-%dT%H:%M:%OS3Z"),"&endDate=",
               strftime(as.POSIXct(paste0(as.Date(endDate), " 23:59:00"), "UTC"), "%Y-%m-%dT%H:%M:%OS3Z"),
               ifelse(is.null(symbol),"",paste0("&symbol=",symbol)),
               ifelse(is.null(types),"",paste0("&types=",types)))
  
  # if(!is.null(symbol)){
  #   URL = paste0("https://api.schwabapi.com/trader/v1/accounts/",accountNumber,"/transactions?startDate=",
  #                startDate,"&endDate=",endDate,"&symbol=",symbol,"&types=",types)  
  # }else{
  #   URL = paste0("https://api.schwabapi.com/trader/v1/accounts/",accountNumber,"/transactions?startDate=",startDate,"&endDate=",endDate,"&types=",types)  
  # }
  # check AccessToken
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  # if page status code is 200 then retrieve page contents
  if(httr::status_code(pg) == 200){
    # account values
    tbl = httr::content(pg)
    # ************************************************************************************************************************************************************************
    if(length(tbl)>0){
      # unlist all items and row bind results - final output will be a data frame
      acc = data.frame(rbindlist(lapply(as.list(1:length(tbl)), function(i){data.frame(t(unlist(tbl[[i]])))}),use.names = T,fill = T))
    }else{
      cat("\nNothing to Return!")
      acc = NULL
    }
    # ************************************************************************************************************************************************************************
  }else{
    # return error
    ERROR <- content(pg)
    cat("\n",ERROR$message,"\n")
    # will assign df as NULL
    acc = NULL
  }
  # return account info
  acc
}
# ************************************************************************************************************************************************
#                                           getOrders functions : file.edit("cs_orders.Rmd") & file.edit("cs_ComplexOrders.Rmd")
# ************************************************************************************************************************************************
cs_buildOptSym = function(under_sym, exp, type, strike){
  sym = str_pad(under_sym, width=6, side = "right")
  exp = format(as.Date(exp),"%y%m%d")
  strike = as.character(as.integer(strike*100))
  if(str_length(strike) == 7){strike = paste0(strike,"0")}
  if(str_length(strike) == 6){strike = paste0("0",strike,"0")}
  if(str_length(strike) == 5){strike = paste0("00",strike,"0")}
  if(str_length(strike) == 4){strike = paste0("000",strike,"0")}
  if(str_length(strike) == 3){strike = paste0("0000",strike,"0")}
  if(str_length(strike) == 2){strike = paste0("00000",strike,"0")}
  paste0(sym,exp,type,strike)
}

#'@param accNum  = hashed account number
#'@param ticker  = stock/etf symbol
#'@param side    = `BUY`, `SELL`, etc, *see table above*
#'@param sess    = session  : `NORMAL` or `AM` or `PM` or `SEAMLESS`
#'@param dur     = duration : `DAY` or `GOOD_TILL_CANCEL` or `FILL_OR_KILL`
#'@param ordType = `MARKET` or `LIMIT`
#'@param qty     = number of shares to purchases
#'@param lmtPrc  = the limit price (FOR `LIMIT` orders)
#'@param aType   = the asset type `EQUITY` or `OPTION`

cs_placeSingleOrder = function(accNum, ticker, side, sess, dur, ordType, qty, lmtPrc=NULL, aType){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # if limit price is set and order type is limit modify price | market orders must set price to ''
  lmtPrc = ifelse(ordType == "LIMIT" & !is.null(lmtPrc), as.character(round(as.numeric(lmtPrc),2)), '')
  # create payload
  payload =  toJSON(list(orderType = ordType,
                         session = sess,
                         duration = dur,
                         price = lmtPrc,
                         orderStrategyType = "SINGLE",
                         orderLegCollection = list(list(
                           instruction = side,
                           quantity = qty,
                           instrument = list(
                             symbol = ticker,
                             assetType = aType)))),auto_unbox = TRUE)  
  
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}

#'@param accNum  = hashed account number
#'@param orderID = The order ID generated from sending order
#'@param ticker  = stock/etf symbol
#'@param side    = `BUY`, `SELL`, etc, *see table above*
#'@param sess    = session  : `NORMAL` or `AM` or `PM` or `SEAMLESS`
#'@param dur     = duration : `DAY` or `GOOD_TILL_CANCEL` or `FILL_OR_KILL`
#'@param ordType = `MARKET` or `LIMIT`
#'@param qty     = number of shares to purchases
#'@param lmtPrc  = the limit price (FOR `LIMIT` orders)
#'@param aType   = the asset type `EQUITY` or `OPTION`

cs_replaceSingleOrder = function(accNum, orderID, ticker, side, sess, dur, ordType, qty, lmtPrc=NULL, aType){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders/',orderID)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # if limit price is set and order type is limit modify price | market orders must set price to ''
  lmtPrc = ifelse(ordType == "LIMIT" & !is.null(lmtPrc), as.character(round(as.numeric(lmtPrc),2)), '')
  # create payload
  payload =  toJSON(list(orderType = ordType,
                         session = sess,
                         duration = dur,
                         price = lmtPrc,
                         orderStrategyType = "SINGLE",
                         orderLegCollection = list(list(
                           instruction = side,
                           quantity = qty,
                           instrument = list(
                             symbol = ticker,
                             assetType = aType)))),auto_unbox = TRUE)  
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::PUT(url = URL, 
                 body = payload,
                 httr::add_headers(`Content-Type` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token)),
                 encode = "json"
                 
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}

#'@param accNum  = hashed account number
#'@param sym1    = option symbol #1
#'@param sym2    = option symbol #2
#'@param side1   = order type for *sym1* when opening: <`BUY_TO_OPEN` or `SELL_TO_OPEN`> | when closing: <`BUY_TO_CLOSE` or `SELL_TO_CLOSE`>
#'@param side2   = order type for *sym2* when opening: <`BUY_TO_OPEN` or `SELL_TO_OPEN`> | when closing: <`BUY_TO_CLOSE` or `SELL_TO_CLOSE`>
#'@param dur     = duration : `DAY` or `GOOD_TILL_CANCEL` or `FILL_OR_KILL`
#'@param ordType = `MARKET` or `NET_DEBIT` or `NET_CREDIT` or `NET_ZERO`
#'@param qty1     = number of contracts for *sym1*
#'@param qty2     = number of contracts for *sym2*
#'@param lmtPrc  = the limit price (FOR `NET_DEBIT` & `NET_CREDIT` orders)

cs_VerticalOrd = function(accNum, sym1, sym2, side1, side2, dur, ordType, qty1, qty2, lmtPrc=NULL){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # if limit price is set and order type is limit modify price | market orders must set price to ''
  lmtPrc = ifelse((ordType == "NET_DEBIT" | ordType == "NET_CREDIT") & !is.null(lmtPrc), as.character(round(as.numeric(lmtPrc),2)), '')
  # create payload
  payload = toJSON(list(orderStrategyType = "SINGLE",
                        orderType = ordType,
                        price = lmtPrc,
                        orderLegCollection = structure(list(
                          instrument = structure(list(assetType = c("OPTION","OPTION"),
                                                      symbol = c(sym1,sym2)),
                                                 class = "data.frame",row.names = 1:2),
                          instruction = c(side1,side2),
                          quantity = c(qty1, qty2)),
                          class = "data.frame",row.names = 1:2),
                        complexOrderStrategyType = "CUSTOM",
                        duration = dur,
                        session = "NORMAL"),
                   auto_unbox = TRUE)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}

#'@param          accNum = The encrypted ID of the account
#'@param      maxResults = The max number of orders to retrieve. Default is 3000.
#'@param fromEnteredTime = Specifies that no orders entered before this time should be returned. Valid ISO-8601 formats are :
#'                         yyyy-MM-dd'T'HH:mm:ss.SSSZ Date must be within 60 days from today's date. 'toEnteredTime' must also be set.
#'@param   toEnteredTime = Specifies that no orders entered after this time should be returned.Valid ISO-8601 formats are :
#'                         yyyy-MM-dd'T'HH:mm:ss.SSSZ. 'fromEnteredTime' must also be set.
#'@param          status = Specifies that only orders of this status should be returned. Available:
#'                         `AWAITING_PARENT_ORDER`, `AWAITING_CONDITION`, `AWAITING_STOP_CONDITION`, `AWAITING_MANUAL_REVIEW`, `ACCEPTED`, `AWAITING_UR_OUT`, 
#'                         `PENDING_ACTIVATION`, `QUEUED`, `WORKING`, `REJECTED`, `PENDING_CANCEL`, `CANCELED`, `PENDING_REPLACE`, `REPLACED`, `FILLED`, `EXPIRED`,
#'                         `NEW`, `AWAITING_RELEASE_TIME`, `PENDING_ACKNOWLEDGEMENT`, `PENDING_RECALL`, `UNKNOWN`   

cs_getOrders = function(accNum, maxResults=NULL, fromEnteredTime, toEnteredTime, status=NULL){
  # format date/times to required ISO-8601 format
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders?',
               ifelse(is.null(maxResults),'maxResults=3000',paste0('maxResults=',maxResults)),
               ifelse(is.null(fromEnteredTime),'',
                      paste0('&fromEnteredTime=',strftime(as.POSIXct(paste0(as.Date(fromEnteredTime), " 00:01:00"), "UTC"), "%Y-%m-%dT%H:%M:%OS3Z"))),
               ifelse(is.null(toEnteredTime),'',
                      paste0('&toEnteredTime=',strftime(as.POSIXct(paste0(as.Date(toEnteredTime), " 23:59:00"), "UTC"), "%Y-%m-%dT%H:%M:%OS3Z"))),
               ifelse(is.null(status),'',paste0('&status=',status))
  )
  
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::GET(url = URL, 
                 httr::add_headers(`accept` = 'application/json',
                                   `Authorization` = paste0("Bearer ",pw$acc_token))
                 
  )
  if(pg$status_code == 200){
    # extract page contents
    tbl = httr::content(pg)
    if(length(tbl) != 0){
      # rbind all results 
      tbl = lapply(as.list(1:length(tbl)), function(i){
        # subset tables in list
        tmp = tbl[[i]]
        # unlist and convert to table
        data.frame(t(unlist(tmp)))
      })
      # row bind all results
      tbl <- as.data.frame(rbindlist(tbl,use.names = T,fill = T))
    }
    
  }else{
    tbl <- NULL
  }
  tbl
}

#'@param accNum  = hashed account number
#'@param orderID  = stock/etf symbol
# cancel orders by order ID
cs_cancelOrder= function(accNum, orderID){
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders/',orderID)
  # check access token
  checkAccessToken(printMsg = FALSE)
  # DELETE request 
  pg <- httr::DELETE(URL,httr::add_headers( `Authorization` = paste0("Bearer ",pw$acc_token)), encode = "json")
  if(pg$status_code == 200){cat("\n",sprintf("%-10s # %-20s", "Successfully Canceled Order", orderID))}
}


#'@param accNum   = hashed account number
#'@param sym      = ticker symbol for stock/etf, or option
#'@param side1    = order type for *see table* 
#'@param side2    = order type for *see table*
#'@param ordType1 = `MARKET` or `LIMIT` 
#'@param ordType2 = `LIMIT` or `STOP` or `STOP_LIMIT`
#'@param qty      = number of shares/contracts for *sym*
#'@param lmtPrc1  = the *entry* limit price for the asset
#'@param lmtPrc2  = the *exit* limit price for the asset
#'@param sess     = session  : `NORMAL` or `AM` or `PM` or `SEAMLESS` (FOR OPTIONS THESE SHOULD BE SET TO `NORMAL`)
#'@param aType    = the asset type `EQUITY` or `OPTION`
#'@param stopPrc  = stop price for `STOP_LIMIT` or `STOP` orders

cs_oto_order = function(accNum, sym, side1, side2, ordType1, ordType2, qty, lmtPrc1=NULL, lmtPrc2=NULL, sess, aType, stopPrc=NULL){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # if limit price is set and order type is limit modify price | market orders must set price to ''
  lmtPrc1 = ifelse(ordType1 == 'LIMIT' & !is.null(lmtPrc1), as.character(round(as.numeric(lmtPrc1),2)), '')
  # add for stop orders
  if(ordType2 == 'STOP' & !is.null(stopPrc)){
    stopPRC <- as.character(round(as.numeric(stopPrc),2))
    lmtPrc2 <- ''
  }
  if(ordType2 == 'STOP_LIMIT' & !is.null(stopPrc) & !is.null(lmtPrc2)){
    stopPRC <- as.character(round(as.numeric(stopPrc),2))
    lmtPrc2 <- as.character(round(as.numeric(lmtPrc2),2))
  }
  if(ordType2 == 'LIMIT' & is.null(stopPrc) & !is.null(lmtPrc2)){
    stopPRC <- ''
    lmtPrc2 <- as.character(round(as.numeric(lmtPrc2),2))
  }
  
  
  # create payload
  payload =   toJSON(list(orderType = ordType1, 
                          session = sess,
                          price = lmtPrc1, 
                          duration = "DAY", 
                          orderStrategyType = "TRIGGER", 
                          orderLegCollection = structure(list(
                            instruction = side1, 
                            quantity = qty, 
                            instrument = structure(list(
                              symbol = sym,
                              assetType = aType), 
                              class = "data.frame", row.names = 1L)), class = "data.frame", row.names = 1L), 
                          childOrderStrategies = structure(list(orderType = ordType2, 
                                                                session = sess,
                                                                price = lmtPrc2,
                                                                stopPrice = stopPRC,
                                                                duration = "DAY", 
                                                                orderStrategyType = "SINGLE", 
                                                                orderLegCollection = list(
                                                                  structure(list(instruction = side2, 
                                                                                 quantity = qty, 
                                                                                 instrument = structure(list(symbol = sym, 
                                                                                                             assetType = aType), 
                                                                                                        class = "data.frame",row.names = 1L)), 
                                                                            class = "data.frame",row.names = 1L))),class = "data.frame",row.names = 1L)),
                     auto_unbox = TRUE)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}

#'@param         accNum = hashed account number
#'@param            sym = ticker symbol for stock/etf, or option
#'@param          side1 = order type for *see table* 
#'@param          side2 = order type for *see table*
#'@param entry_ord_type = `MARKET` or `LIMIT` 
#'@param    sl_ord_type = `STOP` or `STOP_LIMIT`
#'@param            qty = number of shares/contracts for *sym*
#'@param      entry_prc = the *entry* limit price for the asset 
#'@param         tp_prc = the *exit* take-profit limit price for the asset
#'@param       stop_prc = the *exit* market stop price for the asset
#'@param   stop_lmt_prc = the *exit* market limit stop price for the asset
#'@param          aType = the asset type `EQUITY` or `OPTION`

cs_ot_oco_order = function(accNum, sym, side1, side2, entry_ord_type, sl_ord_type, qty, entry_prc=NULL, tp_prc=NULL, stop_prc=NULL, stop_lmt_prc=NULL, aType){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # if limit price is set and order type is limit modify price | market orders must set price to ''
  entry_prc = ifelse(entry_ord_type == 'LIMIT' & !is.null(entry_prc), as.character(round(as.numeric(entry_prc),2)), '')
  # add for stop orders
  if(sl_ord_type == 'STOP' & !is.null(stop_prc)){
    stop_prc <- as.character(round(as.numeric(stop_prc),2))
    stop_lmt_prc <- ''
  }
  if(sl_ord_type == 'STOP_LIMIT' & !is.null(stop_prc) & !is.null(stop_lmt_prc)){
    stop_prc <- as.character(round(as.numeric(stop_prc),2))
    stop_lmt_prc <- as.character(round(as.numeric(stop_lmt_prc),2))
  }
  if(is.null(stop_prc) & !is.null(stop_lmt_prc)){
    stopPRC <- ''
    stop_lmt_prc <- as.character(round(as.numeric(stop_lmt_prc),2))
  }
  
  # create payload
  payload = toJSON(list(orderStrategyType = "TRIGGER",
                        session = "NORMAL", 
                        duration = "DAY", 
                        orderType = entry_ord_type,
                        price = entry_prc, 
                        orderLegCollection = structure(list(
                          instruction = side1, 
                          quantity = qty, 
                          instrument = structure(list(
                            assetType = aType,
                            symbol = sym), 
                            class = "data.frame",row.names = 1L)), class = "data.frame",row.names = 1L), 
                        childOrderStrategies = structure(list(orderStrategyType = "OCO", 
                                                              childOrderStrategies = list(structure(list(orderStrategyType = c("SINGLE","SINGLE"), 
                                                                                                         session = c("NORMAL","NORMAL"), 
                                                                                                         duration = c("GOOD_TILL_CANCEL","GOOD_TILL_CANCEL"), 
                                                                                                         orderType = c("LIMIT", sl_ord_type), 
                                                                                                         price = c(tp_prc, stop_lmt_prc), 
                                                                                                         orderLegCollection = list(structure(list(
                                                                                                           instruction = side2, 
                                                                                                           quantity = qty, 
                                                                                                           instrument = structure(list(
                                                                                                             assetType = aType,
                                                                                                             symbol = sym),
                                                                                                             class = "data.frame",row.names = 1L)), 
                                                                                                           class = "data.frame", row.names = 1L), 
                                                                                                           structure(list(instruction = side2, 
                                                                                                                          quantity = qty, 
                                                                                                                          instrument = structure(list(assetType = aType, 
                                                                                                                                                      symbol = sym), 
                                                                                                                                                 class = "data.frame",row.names = 1L)), 
                                                                                                                     class = "data.frame",row.names = 1L)), 
                                                                                                         stopPrice = c('',stop_prc)), 
                                                                                                    class = "data.frame", row.names = 1:2))), 
                                                         class = "data.frame",row.names = 1L)),
                   auto_unbox = TRUE)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}


#'@param    accNum = hashed account number
#'@param       sym = ticker symbol for stock/etf, or option
#'@param       qty = number of shares/contracts for *sym*
#'@param linkBasis = `MANUAL` or `BASE` or `TRIGGER` or `LAST` or `BID` or `ASK` or `ASK_BID` or `MARK` or `AVERAGE`
#'@param  linkType = `VALUE` or `PERCENT` or `TICK`
#'@param   pOffset = price offset (ex. linkType is Percent -> pOffset == 3%)
#'@param     aType = the asset type `EQUITY` or `OPTION`

cs_trail_stop_order = function(accNum, sym, qty, linkBasis, linkType, pOffset, aType){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # create payload
  payload = toJSON(list(complexOrderStrategyType = "NONE", 
                        orderType = "TRAILING_STOP", 
                        session = "NORMAL", 
                        stopPriceLinkBasis = linkBasis,
                        stopPriceLinkType = linkType, 
                        stopPriceOffset = pOffset, 
                        duration = "DAY", 
                        orderStrategyType = "SINGLE", 
                        orderLegCollection = structure(list(instruction = "SELL", 
                                                            quantity = qty,
                                                            instrument = structure(list(symbol = sym, 
                                                                                        assetType = aType), 
                                                                                   class = "data.frame", row.names = 1L)), 
                                                       class = "data.frame", row.names = 1L)),
                   auto_unbox = TRUE)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}

#'@param        accNum = hashed account number
#'@param           sym = ticker symbol for stock/etf, or option
#'@param           qty = number of shares/contracts for *sym*
#'@param        tp_prc = take-profit price
#'@param     stop_type = `STOP` (market) or `STOP_LIMIT`
#'@param      stop_prc = stop price 
#'@param  stop_lmt_prc = stop limit price (if applicable)
#'@param           dur = duration : `DAY` or `GOOD_TILL_CANCEL` or `FILL_OR_KILL`
#'@param         aType = the asset type `EQUITY` or `OPTION`

cs_oco_order = function(accNum, sym, qty, tp_prc, stop_type, stop_prc, stop_lmt_prc=NULL, dur, aType){
  # build URL
  URL = paste0('https://api.schwabapi.com/trader/v1/accounts/',accNum,'/orders')
  # ************************************************************************************************************
  # ************************************************************************************************************
  # depending on the stop, we have to configure the pricing 
  if(stop_type == "STOP_LIMIT" & !is.null(stop_lmt_prc)){
    stop_lmt_prc = round(as.numeric(stop_lmt_prc), 2)
    stop_prc = round(as.numeric(stop_prc), 2)
  }
  if(stop_type == "STOP"){
    stop_lmt_prc = ''
    stop_prc = round(as.numeric(stop_prc), 2)
  }
  # make sure pricing is rounded to 2-decimals
  tp_prc = round(as.numeric(tp_prc),2)
  
  # create payload
  payload = toJSON(list(orderStrategyType = "OCO", 
                        childOrderStrategies = structure(list(
                          orderType = c("LIMIT", stop_type), 
                          session   = c("NORMAL", "NORMAL"), 
                          price     = c(tp_prc, stop_lmt_prc), 
                          duration  = c(dur, dur), 
                          orderStrategyType = c("SINGLE","SINGLE"), 
                          orderLegCollection = list(
                            structure(list(instruction = "SELL", 
                                           quantity = qty, 
                                           instrument = structure(list(
                                             symbol = sym,
                                             assetType = aType), 
                                             class = "data.frame",row.names = 1L)), 
                                      class = "data.frame",row.names = 1L), 
                            structure(list(instruction = "SELL", 
                                           quantity = qty, 
                                           instrument = structure(list(
                                             symbol = sym, 
                                             assetType = aType),
                                             class = "data.frame",row.names = 1L)), 
                                      class = "data.frame",row.names = 1L)), 
                          stopPrice = c('', stop_prc)), 
                          class = "data.frame",row.names = 1:2)),
                   auto_unbox = TRUE)
  # ************************************************************************************************************
  # ************************************************************************************************************
  # check access token
  checkAccessToken(printMsg = FALSE)
  # get request
  pg = httr::POST(url = URL, 
                  body = payload,
                  httr::add_headers(`Content-Type` = 'application/json',
                                    `Authorization` = paste0("Bearer ",pw$acc_token)),
                  encode = "json"
                  
  )
  
  if(pg$status_code == 201){
    # extract Order ID from URL 
    orderNum = gsub('.*orders/','',pg$headers$location)
  }else{
    orderNum = rawToChar(pg$content)
  }
  # return order ID
  orderNum
}
