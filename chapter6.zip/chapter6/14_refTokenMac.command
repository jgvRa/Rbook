#!/bin/bash
Rscript /Volumes/6TB/R/csAutoRef.R
