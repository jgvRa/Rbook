# load require packages
suppressPackageStartupMessages(require("httr"))
suppressPackageStartupMessages(require("data.table"))
suppressPackageStartupMessages(require("dplyr"))
suppressPackageStartupMessages(require("quantmod"))
# environment to store apiKey
pw <- new.env()
# insert your API KEY: 
assign("apiKey","INSERT_YOUR_API_KEY_HERE",envir = pw)
# ************************************************************************************************************************
# build wrapper for simple quotes
getQuoteFH = function(stk,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/quote?symbol=",stk,"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  qte <- httr::content(pg) %>% suppressWarnings()
  # convert to data frame
  qte <- as.data.frame(do.call(cbind,qte))
  # change column names
  colnames(qte) <- c("curPRC","change","pctChange","high","low","open","prevClose","timeStamp")
  # format timestamp - set to Eastern Time
  qte$timeStamp <- as.POSIXct(qte$timeStamp,origin = "1970-01-01",tz = "America/New_York")
  # add stock symbol as column
  qte$symbol <- stk
  # return data
  qte
}
# build wrapper for OHLCV data
getStkCandlesFH = function(stk,res,from,to=Sys.Date(),apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/stock/candle?symbol=",stk,"&resolution=",res,"&from=",
                as.numeric(as.POSIXct(from)),"&to=",as.numeric(as.POSIXct(to)),"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # convert to data frame
  df <- as.data.frame(do.call(cbind,df))
  # re-order columns
  df <- df[,c("t","o","h","l","c","v")]
  # change column names
  colnames(df) <- c("timeStamp","open","high","low","close","volume")
  # change column class
  df$timeStamp <- sapply(df$timeStamp, as.numeric)
  df$open      <- sapply(df$open, as.numeric)
  df$high      <- sapply(df$high, as.numeric)
  df$low       <- sapply(df$low, as.numeric)
  df$close     <- sapply(df$close, as.numeric)
  df$volume    <- sapply(df$volume, as.numeric)
  # format timestamp - set to Eastern Time
  df$timeStamp <- as.POSIXct(df$timeStamp,origin = "1970-01-01",tz = "America/New_York")
  # add stock symbol as column
  df$symbol <- stk
  # return data
  df
}
# build wrapper for crypto OHLCV data
getCryptoCandlesFH = function(crypto,res,from,to=Sys.Date(),apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/crypto/candle?symbol=BINANCE:",crypto,"&resolution=",res,"&from=",
                as.numeric(as.POSIXct(from)),"&to=",as.numeric(as.POSIXct(to)),"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # convert to data frame
  df <- as.data.frame(do.call(cbind,df))
  # re-order columns
  df <- df[,c("t","o","h","l","c","v")]
  # change column names
  colnames(df) <- c("timeStamp","open","high","low","close","volume")
  # change column class
  df$timeStamp <- sapply(df$timeStamp, as.numeric)
  df$open      <- sapply(df$open, as.numeric)
  df$high      <- sapply(df$high, as.numeric)
  df$low       <- sapply(df$low, as.numeric)
  df$close     <- sapply(df$close, as.numeric)
  df$volume    <- sapply(df$volume, as.numeric)
  # format timestamp - set to Eastern Time
  df$timeStamp <- as.POSIXct(df$timeStamp,origin = "1970-01-01",tz = "America/New_York")
  # add crypto symbol as column
  df$symbol <- crypto
  # return data
  df
}
# build wrapper for social sentiment - reddit/twitter
getSocialSentFH = function(stk,apiKey,from=NULL,to=NULL){
  # create url
  if(is.null(from) & is.null(to)){
    url <- paste0("https://finnhub.io/api/v1/stock/social-sentiment?symbol=",stk,"&token=",apiKey)
  }else{
    url <- paste0("https://finnhub.io/api/v1/stock/social-sentiment?symbol=",stk,"&from=",
                  as.numeric(as.POSIXct(from)),"&to=",as.numeric(as.POSIXct(to)),"&token=",apiKey)
  }
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  if(length(df$reddit) > 0){
    # convert to data frame
    reddit <- as.data.frame(do.call(rbind,df$reddit))
    reddit$source <- "reddit"
    reddit$symbol <-  stk
  }else{
    reddit <- NULL
  }
  if(length(df$twitter) > 0){
    # convert to data frame
    twitter <- as.data.frame(do.call(rbind,df$twitter))
    twitter$source <- "twitter"
    twitter$symbol <-  stk
  }else{
    twitter <- NULL
  }
  # row bind results
  res = rbind(reddit,twitter)
  # return data
  res
}
# build wrapper for earnigns calendar
getEarningsCalFH = function(apiKey,from=NULL,to=NULL,stk=NULL,international=NULL){
  # create url
  if(is.null(from) & is.null(to) & is.null(stk) & is.null(international)){
    url <- paste0("https://finnhub.io/api/v1/calendar/earnings?&token=",apiKey)
  }else{
    url <- paste0("https://finnhub.io/api/v1/calendar/earnings?symbol=",stk,"&from=",
                  as.numeric(as.POSIXct(from)),"&to=",as.numeric(as.POSIXct(to)),"&international=",
                  international,"&token=",apiKey)
  }
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df$earningsCalendar,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for earnings surprises
getEarningsSuprisesFH = function(stk,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/stock/earnings?symbol=",stk,"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for IPO Calendar
getIPOCalFH = function(from,to,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1//calendar/ipo?from=",from,"&to=",to,"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df$ipoCalendar,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for SEC Financial Data
getFinancialsFH = function(stk,cik=NULL,accessNumber=NULL,freq,from=NULL,to=NULL,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/stock/financials-reported?symbol=",stk,"&freq=",freq,"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  RES = lapply(as.list(1:length(df$data)), function(ii){
    #cat("\n",ii)
    # current filing
    tmp = df$data[[ii]]
    #  balance sheet
    BS <- as.data.frame(rbindlist(tmp$report$bs, use.names = TRUE, fill = TRUE))
    BS$rep <- "balanceSheet"
    # income statement
    IS <- as.data.frame(rbindlist(tmp$report$ic,use.names = TRUE, fill = TRUE))
    IS$rep <- "incomeStatement"
    # cash flow statement
    CF <- as.data.frame(rbindlist(tmp$report$cf, use.names = TRUE, fill = TRUE))
    CF$rep <- "cashFlowStatement"
    # row bind all reports
    ALL <- as.data.frame(rbind(BS,IS,CF))
    # add report details
    ALL$accNum <- tmp$accessNumber
    ALL$symbol <- tmp$symbol
    ALL$cik <- tmp$cik
    ALL$year <- tmp$year
    ALL$quarter <- tmp$quarter
    ALL$form <- tmp$form
    ALL$startDate <- tmp$startDate
    ALL$endDate <- tmp$endDate
    ALL$filedDate <- tmp$filedDate
    ALL$acceptedDate <- tmp$acceptedDate
    # make sure it is data frame
    as.data.frame(ALL)
  })
  res = as.data.frame(rbindlist(RES,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for insider Sentiment
getInsiderSentimentFH = function(stk,from,to,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/stock/insider-sentiment?symbol=",stk,"&from=",from,"&to=",to,"&token=",apiKey)
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df$data,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for Insider Transactions
getInsiderTransactionstFH = function(stk,apiKey,from=NULL,to=NULL){
  # create url
  if(is.null(from) & is.null(to)){
    url <- paste0("https://finnhub.io/api/v1/stock/insider-sentiment?symbol=",stk,"&token=",apiKey)  
  }else{
    url <- paste0("https://finnhub.io/api/v1/stock/insider-transactions?symbol=",stk,"&from=",from,"&to=",to,"&token=",apiKey)
  }
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df$data,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # return data
  res
}
# build wrapper for Basic Financials / Fundamental Ratios
getBasicFinancialsFH = function(stk,apiKey,metric){
  # create url
  url <- paste0("https://finnhub.io/api/v1//stock/metric?symbol=",stk,"&metric=",metric,"&token=",apiKey)  
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # most recent
  recent_metrics <- as.data.frame(do.call(rbind,df[["metric"]]))
  recent_metrics <- data.frame(period = as.character(Sys.Date()), v=recent_metrics$V1, type=rownames(recent_metrics), series="mostRecent")
  # ***************************************************************************************************************************
  # annual metrics
  annual_names <- names(df$series$annual[lapply(df$series$annual,length)>0])
  # get all annual metric
  annual_metrics = do.call(rbind,lapply(as.list(annual_names), function(x){
    # extract data
    tmp <- as.data.frame(do.call(rbind,df$series$annual[[x]]))
    # assign metric type
    tmp$type = x
    # assign series type
    tmp$series = "annual"
    # return data
    tmp
  })) %>% as.data.frame
  # ***************************************************************************************************************************
  # quarterly metrics
  quart_names <- names(df$series$quarterly[lapply(df$series$quarterly,length)>0])
  # get all quarterly metric
  quart_metrics = do.call(rbind,lapply(as.list(quart_names), function(x){
    # extract data
    tmp <- as.data.frame(do.call(rbind,df$series$quarterly[[x]]))
    # assign metric type
    tmp$type = x
    # assign series type
    tmp$series = "quarterly"
    # return data
    tmp
  })) %>% as.data.frame
  # ***************************************************************************************************************************
  # row bind all
  res <- as.data.frame(rbind(recent_metrics, quart_metrics, annual_metrics))
  # reclass
  res$period <- sapply(res$period, as.character)
  res$v <- sapply(res$v, as.numeric)
  res$type <- sapply(res$type, as.character)
  res$series <- sapply(res$series, as.character)
  # return data
  res
}
# build wrapper for Company News (Headlines)
getCompanyNewsFH = function(stk,from,to,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/company-news?symbol=",stk,"&from=",from,"&to=",to,"&token=",apiKey)  
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(rbindlist(df,use.names = TRUE, fill = TRUE)) %>% suppressWarnings()
  # fix timestamps
  res$datetime <- as.POSIXct(res$datetime,origin="1970-01-01",tz="America/New_York")
  # return data
  res
}
# build wrapper for Company Profile
getCompanyProfileFH = function(stk,apiKey){
  # create url
  url <- paste0("https://finnhub.io/api/v1/stock/profile2?symbol=",stk,"&token=",apiKey)  
  # get request
  pg <- GET(url)
  # extract content
  df <- httr::content(pg) %>% suppressWarnings()
  # row bind results
  res = as.data.frame(do.call(cbind,df)) %>% suppressWarnings()
  # return data
  res
}
# ************************************************************************************************************************