require("quantmod");require("lubridate");require("pbapply")
# source("getOptionSymbolsDB.R")
# source("getSymbolsDB.R")
# buying straddles before earnings: How many days before earnings?
load("TSLAstraddle.RData")

# $TSLA earnings dates: https://finance.yahoo.com/calendar/earnings?symbol=TSLA
stk = "TSLA"
eDates = c("2021-04-26","2021-07-26","2021-10-20","2022-01-26","2022-04-20","2022-07-20")
eDates = as.Date(eDates)

# get option data
opData = pblapply(as.list(1:length(eDates)), function(ii){
  # function to get Options Closest to the expiration date
  ops = getOpSymbolsByTickerClosestTo(ticker = stk, from=eDates[ii]-days(14), to=eDates[ii], closestTo = eDates[ii])
  # select needed columns only
  ops = ops[,c("option","last_trade_price","expiry","flag","strike","stkClose","Date","days2Exp","bid","Mid","ask")]
  # select straddle at each close
  # run each day
  DAYS <- unique(ops$Date) 
  ops = lapply(as.list(DAYS), function(dd){
    # subset by date
    tmp <- subset(ops,ops$Date == dd)
    # find ATM ops
    tmp$diff <- abs(tmp$strike-tmp$stkClose)
    # select call/put
    CALL <- subset(tmp, tmp$flag == "C")
    PUT <- subset(tmp, tmp$flag == "P")
    CALL <- CALL[which.min(CALL$diff),c("expiry","strike","stkClose","Date","days2Exp","Mid")]
    colnames(CALL) <- c("expiry","cStrike","stkClose","Date","days2Exp","cMid")
    PUT  <- PUT[which.min(PUT$diff),c("strike","Mid","diff")]
    colnames(PUT) <- c("pStrike","pMid","diff")
    tmp <- cbind(CALL,PUT)
    # calculate breakevens + total Cost
    tmp$totalCost <- round(tmp$cMid + tmp$pMid,2)
    tmp$upBE <- tmp$cStrike + tmp$totalCost
    tmp$dnBE <- tmp$pStrike - tmp$totalCost
    # return data frame
    as.data.frame(tmp[,c("expiry","cStrike","pStrike","stkClose","diff",
                         "Date","days2Exp","cMid","pMid","totalCost",
                         "upBE","dnBE")])
  }) 
  # combine
  ops = do.call(rbind,ops)
  # subset days2Exp > 7 [implied vol. will be greater the closer to Exp.]
  ops <- subset(ops, ops$days2Exp >= 7)
  # add underlying close @ Expiration
  ops$stkAtexp <- as.numeric(getSymbolsDB(stk)[paste(ops$expiry[1])])
  # calculate PnL
  ops$cAtexp <- ifelse(ops$stkAtexp >= ops$cStrike,ops$stkAtexp - ops$cStrike,0) # call price @ Exp
  ops$pAtexp <- ifelse(ops$stkAtexp <= ops$pStrike,ops$pStrike - ops$stkAtexp,0) # put price @ Exp
  ops$totalWorth <- ops$cAtexp + ops$pAtexp
  ops$PnL <- ops$totalWorth - ops$totalCost
  # store option data
  ops
})
# combine data
opData <- as.data.frame(do.call(rbind,opData))

# extract days to expiration
d2e <- unique(opData$days2Exp)

# summary:
OUT <- do.call(rbind,lapply(as.list(d2e), function(d2e){
  # subset by days 2 exp.
  ops <- subset(opData, opData$days2Exp == d2e)
  # number of obs
  N <- nrow(ops)
  # avg PnL
  AVG <- mean(ops$PnL)
  # number of gainers
  UP <- sum(ops$PnL > 0)
  # number of losers
  DN <- sum(ops$PnL < 0)
  # win %
  WIN <- round(UP/N,4)
  # Max Win
  maxWin <- max(ops$PnL)
  # Max Loss
  maxLoss <- min(ops$PnL)
  # combine as data frame
  OUT <- as.data.frame(cbind(d2e,N,AVG,UP,DN,WIN,maxWin,maxLoss))
  colnames(OUT) <- c("days2Exp","nObs","Avg","nGainers","nLosers","winPct","maxWin","maxLoss")
  OUT
}))

#save.image("TSLAstraddle.RData")
