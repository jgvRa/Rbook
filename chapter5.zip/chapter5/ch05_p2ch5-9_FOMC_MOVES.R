require("quantmod");require("RQuantLib");require("pbapply")

# FOMC Statement Dates - https://www.investing.com/economic-calendar/fomc-statement-398
FOMC <- c("2020-11-05","2020-12-16","2021-01-27","2021-03-17","2021-04-28","2021-06-16","2021-07-28",
          "2021-09-22","2021-11-03","2021-12-15","2022-01-26","2022-03-16","2022-05-04","2022-06-15",
          "2022-07-27","2022-09-21","2022-11-02","2022-12-14")
# convert to dates
FOMC <- as.Date(FOMC)
# select past dates only
FOMC <- FOMC[FOMC < Sys.Date()]
# FOMC <- FOMC[FOMC >= as.Date("2022-01-01")]
# assets/stocks to backtest moves
stks <- c("SPY","^TNX","^VIX","EURUSD=X","BTC-USD","GLD")
# create a new environment to store stock data
e<- new.env()
# get data from Yahoo
getSymbols(stks,env = e, from="2020-10-15")
# merge all the Adjusted Closes together
DATA <- do.call(merge, eapply(e, Ad))
# only get trading days (since BTC trades 24/7)
DATA <- DATA[isBusinessDay(calendar = "UnitedStates/NYSE",dates =index(DATA)),]
# format column names
colnames(DATA) <- gsub(".Adjusted","",names(DATA))
# get stock names from DATA (different format)
stks <- names(DATA)
# *****************************************************************************************************
# *****************************************************************************************************
# BackTest - extract returns
BT <- lapply(as.list(stks), function(x){
  # returns for symbol
  rets <- ROC(DATA[,x])
  # for each of the FOMC dates calculate returns
  all <- lapply(as.list(FOMC), function(DATE){
    # get the return the day of the meeting
    ret0 <- round(as.numeric(rets[DATE]),4)
    # extract the closing PRC the day of meeting
    meetingPRC <- as.numeric(DATA[,x][DATE])
    # extract the closing PRC the next day: k
    day1 <- as.numeric(head(Next(DATA[,x][paste0(DATE,"::")],k = 1),1))
    # head(DATA[,x][paste0(DATE,"::")],2) # check
    # get the return one-day after
    ret1 <- round(day1/meetingPRC-1,4)
    # extract the closing PRC the next day: k
    day3 <- as.numeric(head(Next(DATA[,x][paste0(DATE,"::")],k = 3),1))
    # get the return 3-days after
    ret3 <- round(day3/meetingPRC-1,4)
    # extract the closing PRC the next day: k
    day5 <- as.numeric(head(Next(DATA[,x][paste0(DATE,"::")],k = 5),1))
    # get the return 5-days after
    ret5 <- round(day5/meetingPRC-1,4)
    # extract the closing PRC the next day: k
    day7 <- as.numeric(head(Next(DATA[,x][paste0(DATE,"::")],k = 7),1))
    # get the return 7-days after
    ret7 <- round(day7/meetingPRC-1,4)
    # combine everything
    stkRets <- as.data.frame(cbind(ret0,ret1,ret3,ret5, ret7))
    # add date and symbol name
    stkRets$Date <- as.character(DATE)
    stkRets$Symbol <- as.character(x)
    # return data frame
    stkRets
  })
  # row bind results
  as.data.frame(do.call(rbind,all))
})
# combine all data - row bind
BT <- do.call(rbind, BT)
# *****************************************************************************************************
# *****************************************************************************************************
# for each stock in the backtest - calculate:
# 1. The Average Return each period
# 2. The standard deviation each period
# 3. The 1-standard deviation expected move (avg +/- stdev)
# 4. Probability of an Up move
# 5. Probability of an Dn move

# extract unique stks
stks <- unique(BT$Symbol)
# RESULTS
RES <- lapply(as.list(stks), function(x){
  # extract the stock's backtest results
  bt <- subset(BT, BT$Symbol == x)
  # calculate the average return
  AVG  <- round(colMeans(bt[,1:5]),5)
  # calculate standard deviation
  STDEV<- round(apply(bt[,1:5],2,sd),5)
  # expected move UP 
  UP <- AVG+STDEV
  # expected move DN
  DN <- AVG-STDEV
  # RANGE
  RANGE <- UP-DN
  # probability of an UP MOVE
  upChance <- round(colSums(bt[,1:5] > 0)/nrow(bt[,1:5]),5)
  # probability of an DN MOVE
  dnChance <- round(colSums(bt[,1:5] < 0)/nrow(bt[,1:5]),5)
  # combine as data frame
  OUT <- as.data.frame(cbind(AVG,STDEV,UP,DN,RANGE,upChance,dnChance),row.names = NA)
  # add column for return period
  OUT$Period <- c("ret0","ret1","ret3","ret5","ret7")
  # add stock symbol
  OUT$Symbol <- x
  # return data.frame
  OUT
})
# combine
RES <- do.call(rbind,RES)

# now we can see stats per period
View(subset(RES,RES$Period == "ret0"))
View(subset(RES,RES$Period == "ret1"))
View(subset(RES,RES$Period == "ret3"))
View(subset(RES,RES$Period == "ret5"))
View(subset(RES,RES$Period == "ret7"))